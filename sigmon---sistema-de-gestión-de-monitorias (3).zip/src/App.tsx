import React, { useState, useMemo } from 'react';
import { 
  Home, 
  BookOpen, 
  Users, 
  CalendarCheck, 
  ClipboardCheck, 
  BarChart3, 
  Contact, 
  Settings,
  Plus,
  Edit2,
  XCircle,
  Search,
  ChevronRight,
  GraduationCap,
  Calendar,
  Clock,
  MapPin,
  CheckCircle2,
  AlertCircle,
  FileText,
  Activity,
  ArrowUpRight,
  MoreVertical,
  Filter,
  UserCheck,
  Download,
  Send
} from 'lucide-react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  LineChart, 
  Line, 
  PieChart, 
  Pie, 
  Cell 
} from 'recharts';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from './lib/utils';
import { Monitor, Asignatura, Oferta, Reserva, TabItem } from './types';
import { DUMMY_MONITORES, DUMMY_ASIGNATURAS, DUMMY_OFERTA } from './constants';

// --- Sub-components for better organization ---

interface StatCardProps {
  label: string;
  value: string | number;
  icon: any;
  color: string;
}

const StatCard: React.FC<StatCardProps> = ({ label, value, icon: Icon, color }) => (
  <motion.div 
    initial={{ opacity: 0, y: 10 }}
    animate={{ opacity: 1, y: 0 }}
    className="bg-white p-5 rounded-xl border border-border-subtle shadow-none flex flex-col justify-between"
  >
    <div className="flex items-center justify-between mb-3">
      <p className="text-[11px] font-bold text-text-muted uppercase tracking-wider">{label}</p>
      <Icon className={cn("w-4 h-4", color.replace('bg-', 'text-').replace('-100', '-600'))} />
    </div>
    <p className="text-2xl font-extrabold text-text-main">{value}</p>
  </motion.div>
);

const SectionHeader = ({ title, desc }: { title: string; desc: string }) => (
  <div className="mb-6">
    <h3 className="text-lg font-bold text-text-main mb-1">{title}</h3>
    <p className="text-xs text-text-muted">{desc}</p>
  </div>
);

const Modal = ({ isOpen, onClose, title, children }: { isOpen: boolean, onClose: () => void, title: string, children: React.ReactNode }) => {
  if (!isOpen) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="bg-white rounded-2xl w-full max-w-lg overflow-hidden shadow-2xl"
      >
        <div className="px-6 py-4 border-b border-border-subtle flex justify-between items-center bg-brand-light">
          <h3 className="font-bold text-brand">{title}</h3>
          <button onClick={onClose} className="p-1 hover:bg-white rounded-full transition-colors">
            <XCircle size={20} className="text-brand" />
          </button>
        </div>
        <div className="p-6">
          {children}
        </div>
      </motion.div>
    </div>
  );
};

export default function App() {
  const [activeTab, setActiveTab] = useState('inicio');
  const [monitores, setMonitores] = useState<Monitor[]>(DUMMY_MONITORES);
  const [ofertas, setOfertas] = useState<Oferta[]>(DUMMY_OFERTA);
  const [userRole, setUserRole] = useState<'admin' | 'monitor' | 'estudiante' | 'catedratico'>('admin');
  const [currentMonitor] = useState<Monitor>(DUMMY_MONITORES[0]); // Simulamos que es Juan Pérez
  
  // Modal States
  const [showOfertaModal, setShowOfertaModal] = useState(false);
  const [showMonitorModal, setShowMonitorModal] = useState(false);
  const [showCSVModal, setShowCSVModal] = useState(false);
  const [showCertModal, setShowCertModal] = useState(false);
  const [showDocenteReportModal, setShowDocenteReportModal] = useState(false);
  const [showMonitorReportModal, setShowMonitorReportModal] = useState(false);
  const [showDecanaturaModal, setShowDecanaturaModal] = useState(false);
  const [bookingSuccess, setBookingSuccess] = useState<string | null>(null);
  const [exportSuccess, setExportSuccess] = useState(false);
  const [isSessionActive, setIsSessionActive] = useState(true);
  const [isExporting, setIsExporting] = useState(false);
  const [reservasRealizadas, setReservasRealizadas] = useState<Reserva[]>([]);
  const [asistenciaHoy, setAsistenciaHoy] = useState([
    { id: 1, name: 'Maria Jose Restrepo', email: 'm.restrepo@univalle.edu.co', status: 'Presente' },
    { id: 2, name: 'Julian Aristizabal', email: 'j.aristi@univalle.edu.co', status: 'Ausente' },
    { id: 3, name: 'Diana Marcela Lopez', email: 'd.lopez@univalle.edu.co', status: 'Presente' },
    { id: 4, name: 'Kevin Estuardo', email: 'k.estuardo@univalle.edu.co', status: 'Presente' },
  ]);
  
  // Edit/Detail States
  const [selectedOferta, setSelectedOferta] = useState<Oferta | null>(null);
  const [selectedMonitor, setSelectedMonitor] = useState<Monitor | null>(null);
  const [showDetailOferta, setShowDetailOferta] = useState(false);
  const [showEditOferta, setShowEditOferta] = useState(false);
  const [showDetailMonitor, setShowDetailMonitor] = useState(false);
  const [showEditMonitor, setShowEditMonitor] = useState(false);
  const [showCancelOfertaModal, setShowCancelOfertaModal] = useState(false);
  const [ofertaToCancel, setOfertaToCancel] = useState<Oferta | null>(null);

  // Form States (Simple)
  const [newOferta, setNewOferta] = useState({ asignaturaId: '', monitorId: '', horario: '', aula: '' });
  const [newMonitor, setNewMonitor] = useState({ nombre: '', email: '', programa: '', promedio: '', asignaturaPrincipal: '' });

  const handleCreateOferta = () => {
    if (!newOferta.asignaturaId || !newOferta.monitorId) return;
    const oferta: Oferta = {
      id: `OF-${Date.now()}`,
      asignaturaId: newOferta.asignaturaId,
      monitorId: newOferta.monitorId,
      horario: newOferta.horario || 'Lunes 14:00 - 16:00',
      aula: newOferta.aula || 'Por definir',
      cuposMax: 20,
      cuposReservados: 0,
      estado: 'Activo'
    };
    setOfertas([oferta, ...ofertas]);
    setShowOfertaModal(false);
    setNewOferta({ asignaturaId: '', monitorId: '', horario: '', aula: '' });
  };

  const handleCreateMonitor = () => {
    if (!newMonitor.nombre || !newMonitor.programa) return;
    const monitor: Monitor = {
      id: `MON-${Date.now()}`,
      nombre: newMonitor.nombre,
      email: newMonitor.email || `${newMonitor.nombre.toLowerCase().replace(/ /g, '.')}@univalle.edu.co`,
      programa: newMonitor.programa,
      promedio: parseFloat(newMonitor.promedio) || 4.0,
      asignaturaPrincipal: newMonitor.asignaturaPrincipal || 'General',
      horasCumplidas: 0,
      estado: 'Activo'
    };
    setMonitores([monitor, ...monitores]);
    setShowMonitorModal(false);
    setNewMonitor({ nombre: '', email: '', programa: '', promedio: '', asignaturaPrincipal: '' });
  };

  const handleUpdateOferta = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedOferta) return;
    setOfertas(ofertas.map(of => of.id === selectedOferta.id ? selectedOferta : of));
    setShowEditOferta(false);
    setSelectedOferta(null);
  };

  const handleCancelOferta = () => {
    if (!ofertaToCancel) return;
    setOfertas(ofertas.map(item => item.id === ofertaToCancel.id ? {...item, estado: 'Cancelado'} : item));
    setShowCancelOfertaModal(false);
    setOfertaToCancel(null);
  };

  const handleUpdateMonitor = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedMonitor) return;
    setMonitores(monitores.map(mon => mon.id === selectedMonitor.id ? selectedMonitor : mon));
    setShowEditMonitor(false);
    setSelectedMonitor(null);
  };

  const handleCSVUpload = () => {
    // Simulate loading
    setTimeout(() => {
      setShowCSVModal(false);
      alert('CSV cargado con éxito. Se han importado 15 nuevas asignaturas.');
    }, 1500);
  };

  const handleCertGenerate = () => {
    // Simulate generation
    setTimeout(() => {
      setShowCertModal(false);
      alert('Certificado generado y descargado con éxito.');
    }, 1500);
  };
  
  const menuItems: TabItem[] = [
    { id: 'inicio', title: 'Inicio', desc: 'Horarios disponibles de monitorias del día', icon: <Home size={18} />, num: 1 },
    { id: 'oferta', title: 'Oferta de Monitorias', desc: 'Asignatura, monitor asignado, horario, aula', icon: <BookOpen size={18} />, num: 2, actions: ['Ingresar', 'Modificar', 'Cancelar', 'Consultar'] },
    { id: 'monitores', title: 'Gestión Monitores', desc: 'Estudiante monitor, programa, promedio, asignatura', icon: <Users size={18} />, num: 3, actions: ['Ingresar', 'Modificar', 'Deshabilitar', 'Consultar'] },
    { id: 'reserva', title: 'Reserva de Sesión', desc: 'Estudiante reserva cupo en una sesión de monitoría', icon: <CalendarCheck size={18} />, num: 4, actions: ['Reservar', 'Cancelar', 'Consultar'] },
    { id: 'validacion', title: 'Validación de Horas', desc: 'Aprobación de clases dictadas por los monitores', icon: <ClipboardCheck size={18} />, num: 5 },
    { id: 'asistencia', title: 'Control de Asistencia', desc: 'Registro de estudiantes que asistieron a la sesión', icon: <ClipboardCheck size={18} />, num: 6 },
    { id: 'reportes', title: 'Reportes PDF', desc: 'Sesiones dictadas, asistencia, monitores activos', icon: <BarChart3 size={18} />, num: 7 },
    { id: 'contactos', title: 'Contactos Soporte', desc: 'Dirección académica del departamento', icon: <Contact size={18} />, num: 8 },
    { id: 'configuracion', title: 'Configuración', desc: 'Asignaturas, tipos usuario, semestre activo', icon: <Settings size={18} />, num: 9 }
  ];

  const filteredMenuItems = useMemo(() => {
    if (userRole === 'admin') return menuItems;
    
    // Student sections
    if (userRole === 'estudiante') {
      const studentAllowed = ['inicio', 'reserva', 'contactos'];
      return menuItems
        .filter(item => studentAllowed.includes(item.id))
        .map(item => {
          if (item.id === 'reserva') return { ...item, title: 'Reservar Cupo', desc: 'Inscribirme en una sesión de monitoría' };
          return item;
        });
    }

    if (userRole === 'monitor') {
      const monitorAllowed = ['inicio', 'oferta', 'asistencia', 'reportes', 'contactos'];
      return menuItems
        .filter(item => monitorAllowed.includes(item.id))
        .map(item => {
          if (item.id === 'oferta') return { ...item, title: 'Mis Monitorias', desc: 'Cursos y horarios que tengo a cargo' };
          if (item.id === 'reportes') return { ...item, title: 'Mis Informes', desc: 'Seguimiento de mis horas y alumnos' };
          return item;
        });
    }

    // Professor (Catedrático) sections
    const profAllowed = ['inicio', 'oferta', 'validacion', 'reportes', 'contactos'];
    return menuItems
      .filter(item => profAllowed.includes(item.id))
      .map(item => {
        if (item.id === 'oferta') return { ...item, title: 'Mis Asignaturas', desc: 'Monitores asignados a mis cursos' };
        if (item.id === 'validacion') return { ...item, title: 'Validar Horas', desc: 'Certificar sesiones de mis monitores' };
        if (item.id === 'reportes') return { ...item, title: 'Impacto Académico', desc: 'Estadísticas de mis grupos' };
        return item;
      });
  }, [userRole, menuItems]);

  const getActionIcon = (action: string) => {
    switch (action) {
      case 'Ingresar': case 'Reservar': return <Plus size={14} />;
      case 'Modificar': return <Edit2 size={14} />;
      case 'Cancelar': case 'Deshabilitar': return <XCircle size={14} />;
      case 'Consultar': return <Search size={14} />;
      default: return null;
    }
  };

  // Stats calculation
  const stats = useMemo(() => {
    if (userRole === 'admin') {
      return [
        { label: 'Monitorias hoy', value: 12, icon: Calendar, color: 'bg-blue-100' },
        { label: 'Monitores activos', value: monitores.filter(m => m.estado === 'Activo').length, icon: UserCheck, color: 'bg-green-100' },
        { label: 'Cupos Reservados', value: 128, icon: CalendarCheck, color: 'bg-orange-100' },
        { label: 'Efectividad', value: '94.2%', icon: Activity, color: 'bg-purple-100' }
      ];
    } else if (userRole === 'monitor') {
      const sessions = ofertas.filter(o => o.monitorId === currentMonitor.id);
      return [
        { label: 'Mis Sesiones', value: sessions.length, icon: BookOpen, color: 'bg-blue-100' },
        { label: 'Horas Acumuladas', value: `${currentMonitor.horasCumplidas}h`, icon: Clock, color: 'bg-green-100' },
        { label: 'Estudiantes Atendidos', value: 42, icon: Users, color: 'bg-orange-100' },
        { label: 'Próxima Sesión', value: 'Hoy 14:00', icon: Calendar, color: 'bg-purple-100' }
      ];
    } else if (userRole === 'catedratico') {
      return [
        { label: 'Monitores a Cargo', value: 4, icon: Users, color: 'bg-indigo-100' },
        { label: 'Sesiones del Mes', value: 24, icon: CalendarCheck, color: 'bg-emerald-100' },
        { label: 'Horas por Validar', value: '12h', icon: Clock, color: 'bg-yellow-100' },
        { label: 'Tasa de Éxito', value: '89%', icon: Activity, color: 'bg-rose-100' }
      ];
    } else {
      return [
        { label: 'Mis Reservas', value: reservasRealizadas.length, icon: CalendarCheck, color: 'bg-blue-100' },
        { label: 'Cupos Disponibles', value: ofertas.reduce((acc, curr) => acc + (curr.cuposMax - curr.cuposReservados), 0), icon: Users, color: 'bg-green-100' },
        { label: 'Horas Asistidas', value: '18h', icon: Clock, color: 'bg-orange-100' },
        { label: 'Puntos Excelencia', value: 850, icon: Activity, color: 'bg-purple-100' }
      ];
    }
  }, [userRole, monitores, ofertas, currentMonitor, reservasRealizadas]);

  // Filtered Ofertas for display
  const displayOfertas = useMemo(() => {
    if (userRole === 'admin' || userRole === 'estudiante' || userRole === 'catedratico') return ofertas;
    return ofertas.filter(o => o.monitorId === currentMonitor.id);
  }, [userRole, ofertas, currentMonitor]);

  // Report Data
  const reportData = [
    { name: 'Cálculo', sesiones: 40 },
    { name: 'Física', sesiones: 30 },
    { name: 'Sistemas', sesiones: 65 },
    { name: 'Matemáticas', sesiones: 45 },
    { name: 'Idiomas', sesiones: 20 },
  ];

  return (
    <div className="min-h-screen bg-page font-sans text-text-main flex flex-col md:flex-row h-screen overflow-hidden">
      {/* Sidebar - Menú Principal */}
      <aside className="w-full md:w-[280px] bg-white border-r border-border-subtle overflow-y-auto flex flex-col z-20">
        <div className="p-6 bg-brand-light border-b border-border-subtle flex flex-col shrink-0">
          <h1 className="font-extrabold text-lg flex items-center gap-2 text-brand leading-none">
            <GraduationCap size={20} />
            SIGMON
          </h1>
          <span className="text-[10px] uppercase text-text-muted mt-1 font-semibold">Dirección Académica v1.0</span>
        </div>

        <div className="flex-1 px-3 py-4 overflow-y-auto custom-scrollbar">
          <nav className="space-y-1">
            {filteredMenuItems.map((item) => (
              <div 
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={cn(
                  "group px-3 py-2.5 rounded-lg cursor-pointer transition-colors flex items-center justify-between text-[13px] font-medium",
                  activeTab === item.id 
                    ? 'bg-brand text-white' 
                    : 'text-text-muted hover:bg-brand-light hover:text-brand'
                )}
              >
                <div className="flex items-center gap-3">
                  <div className={cn(
                    "transition-colors",
                    activeTab === item.id ? "text-white" : "text-text-muted group-hover:text-brand"
                  )}>
                    {item.icon}
                  </div>
                  <span>{item.title}</span>
                </div>
                <span className={cn(
                  "text-[10px] font-mono opacity-60",
                  activeTab === item.id ? "text-white" : "text-text-muted"
                )}>{item.num.toString().padStart(2, '0')}</span>
              </div>
            ))}
          </nav>
        </div>

        <div className="p-6 border-t border-border-subtle shrink-0">
          <div className="text-[11px] font-bold text-text-muted uppercase tracking-wider mb-1">Semestre Actual</div>
          <div className="text-sm font-bold text-brand">2026-1 ACTIVO</div>
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 overflow-y-auto flex flex-col h-full bg-page">
        {/* Header */}
        <header className="h-16 bg-white border-b border-border-subtle px-8 flex items-center justify-between sticky top-0 z-10">
          <div className="text-base font-bold text-text-main flex items-center gap-4">
            Dashboard {userRole === 'admin' ? 'Administrativo' : userRole === 'monitor' ? 'Monitor' : userRole === 'catedratico' ? 'Docente' : 'Estudiante'}
            <div className="flex items-center gap-1 bg-brand-light p-1 rounded-lg">
               <button 
                onClick={() => {
                  setUserRole('admin');
                  setActiveTab('inicio');
                }}
                className={cn(
                  "px-3 py-1 rounded text-[10px] font-bold transition-all",
                  userRole === 'admin' ? "bg-brand text-white shadow-sm" : "text-brand hover:bg-white"
                )}
               >
                 ADMIN
               </button>
               <button 
                onClick={() => {
                  setUserRole('monitor');
                  setActiveTab('inicio');
                }}
                className={cn(
                  "px-3 py-1 rounded text-[10px] font-bold transition-all",
                  userRole === 'monitor' ? "bg-brand text-white shadow-sm" : "text-brand hover:bg-white"
                )}
               >
                 MONITOR
               </button>
               <button 
                onClick={() => {
                  setUserRole('estudiante');
                  setActiveTab('inicio');
                }}
                className={cn(
                  "px-3 py-1 rounded text-[10px] font-bold transition-all",
                  userRole === 'estudiante' ? "bg-brand text-white shadow-sm" : "text-brand hover:bg-white"
                )}
               >
                 ESTUDIANTE
               </button>
               <button 
                onClick={() => {
                  setUserRole('catedratico');
                  setActiveTab('inicio');
                }}
                className={cn(
                  "px-3 py-1 rounded text-[10px] font-bold transition-all",
                  userRole === 'catedratico' ? "bg-brand text-white shadow-sm" : "text-brand hover:bg-white"
                )}
               >
                 DOCENTE
               </button>
            </div>
          </div>
          <div className="flex items-center gap-3">
             <div className="text-right">
               <div className="text-[12px] font-bold text-text-main leading-tight">
                 {userRole === 'admin' ? 'Director de Depto' : userRole === 'monitor' ? currentMonitor.nombre : userRole === 'catedratico' ? 'Dr. Álvaro Guzmán' : 'Estudiante Univalle'}
               </div>
               <div className="text-[10px] text-text-muted font-medium">
                 {userRole === 'admin' ? 'ID: ADM-9021' : userRole === 'monitor' ? `Código: ${currentMonitor.id}` : userRole === 'catedratico' ? 'Docente Titular' : 'Código: 2210452'}
               </div>
             </div>
             <div className="w-8 h-8 bg-brand-light text-brand rounded-full flex items-center justify-center text-[12px] font-bold border border-brand/20">
               {userRole === 'admin' ? 'AD' : userRole === 'monitor' ? currentMonitor.nombre.substring(0, 2).toUpperCase() : userRole === 'catedratico' ? 'AG' : 'ES'}
             </div>
          </div>
        </header>

        <div className="flex-grow flex flex-col overflow-y-auto custom-scrollbar">
          <div className="p-8 max-w-7xl mx-auto w-full">
            <AnimatePresence mode="wait">
              <motion.div
                key={activeTab}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.15 }}
                className="space-y-6"
              >
                {/* Stats Grid */}
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                  {stats.map((stat, idx) => (
                    <StatCard 
                      key={idx} 
                      label={stat.label}
                      value={stat.value}
                      icon={stat.icon}
                      color={stat.color}
                    />
                  ))}
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 items-start">
                  <div className="lg:col-span-2 space-y-6">
                    <div className="bg-white rounded-xl border border-border-subtle p-6">
                      {activeTab === 'inicio' ? (
                        <div className="space-y-6">
                          <div className="flex justify-between items-center mb-4">
                            <h4 className="text-sm font-bold text-text-main">
                              {userRole === 'admin' ? 'Agenda de Monitorias: Hoy' : 'Mi Agenda del Día'}
                            </h4>
                            <span className="text-xs font-semibold text-brand cursor-pointer">Ver Calendario Completo</span>
                          </div>
                          <div className="overflow-x-auto">
                            <table className="w-full text-[13px]">
                              <thead>
                                <tr className="text-text-muted text-[11px] font-bold uppercase tracking-wider border-b-2 border-border-subtle">
                                  <th className="text-left py-3">Horario</th>
                                  <th className="text-left py-3">Asignatura</th>
                                  <th className="text-left py-3">Aula</th>
                                  {userRole === 'admin' && <th className="text-left py-3">Monitor</th>}
                                  <th className="text-left py-3">Estado</th>
                                </tr>
                              </thead>
                              <tbody className="divide-y divide-border-subtle">
                                {[
                                  { time: '08:00 - 10:00', subject: 'Cálculo Diferencial', monitor: 'Andrés López', room: 'Lab 402', status: 'En Curso' },
                                  { time: '10:00 - 12:00', subject: 'Estructuras de Datos', monitor: 'Juan Pérez', room: 'Virtual G3', status: 'Programado' },
                                  { time: '14:00 - 16:00', subject: 'Física Mecánica', monitor: 'Juan Pérez', room: 'Aula 105', status: 'Programado' },
                                  { time: '16:00 - 18:00', subject: 'Programación Web', monitor: 'Sara White', room: 'Lab 201', status: 'Programado' },
                                ].filter(s => userRole === 'admin' || userRole === 'estudiante' || s.monitor === currentMonitor.nombre).map((sesion, i) => (
                                  <tr key={i} className="hover:bg-brand-light/20 transition-colors">
                                    <td className="py-4 font-medium text-text-muted">{sesion.time}</td>
                                    <td className="py-4 font-bold text-text-main">{sesion.subject}</td>
                                    <td className="py-4 text-text-muted">{sesion.room}</td>
                                    {userRole === 'admin' && <td className="py-4 text-text-main font-medium">{sesion.monitor}</td>}
                                    <td className="py-4">
                                      <span className="px-2 py-1 bg-[#dcfce7] text-[#166534] rounded text-[10px] font-bold uppercase">
                                        {sesion.status}
                                      </span>
                                    </td>
                                  </tr>
                                ))}
                              </tbody>
                            </table>
                          </div>
                        </div>
                      ) : null}

                      {activeTab === 'oferta' ? (
                        <div className="space-y-6">
                           <div className="flex justify-between items-center mb-6">
                            <h4 className="text-sm font-bold text-text-main">
                              {userRole === 'admin' ? 'Oferta de Monitorias' : 'Mis Monitorias Asignadas'}
                            </h4>
                             {userRole === 'admin' && (
                               <button 
                                onClick={() => setShowOfertaModal(true)}
                                className="px-4 py-2 bg-brand text-white text-xs font-bold rounded-lg hover:opacity-90 transition-all flex items-center gap-2"
                              >
                                <Plus size={16} />
                                Ingresar
                              </button>
                             )}
                          </div>
                          <div className="overflow-x-auto">
                            <table className="w-full text-[13px]">
                              <thead>
                                <tr className="text-text-muted text-[11px] font-bold uppercase tracking-wider border-b-2 border-border-subtle">
                                  <th className="text-left py-3">Asignatura</th>
                                  {userRole === 'admin' && <th className="text-left py-3">Monitor</th>}
                                  <th className="text-left py-3">Horario</th>
                                  <th className="text-center py-3">Estado</th>
                                  <th className="text-right py-3">Acciones</th>
                                </tr>
                              </thead>
                              <tbody className="divide-y divide-border-subtle">
                                {displayOfertas.map((o) => {
                                   const subject = DUMMY_ASIGNATURAS.find(a => a.id === o.asignaturaId);
                                   const monitor = monitores.find(m => m.id === o.monitorId);
                                   return (
                                     <tr key={o.id} className="hover:bg-brand-light/20 transition-colors">
                                       <td className="py-5">
                                         <p className="font-bold text-text-main">{subject?.nombre}</p>
                                         <p className="text-[10px] text-text-muted">{subject?.codigo}</p>
                                       </td>
                                       {userRole === 'admin' && <td className="py-5 font-medium text-text-main">{monitor?.nombre}</td>}
                                       <td className="py-5">
                                          <p className="font-semibold text-text-muted">{o.horario}</p>
                                          <p className="text-[10px] font-medium text-text-muted italic">{o.aula}</p>
                                       </td>
                                       <td className="py-5 text-center">
                                          <span className={cn(
                                            "px-2 py-1 rounded text-[10px] font-bold uppercase",
                                            o.estado === 'Activo' ? "bg-[#dcfce7] text-[#166534]" : "bg-red-100 text-red-600"
                                          )}>
                                            {o.estado}
                                          </span>
                                       </td>
                                       <td className="py-5 text-right">
                                         <div className="flex items-center justify-end gap-1">
                                           <button 
                                             onClick={() => {
                                               setSelectedOferta(o);
                                               setShowDetailOferta(true);
                                             }}
                                             className="p-1.5 text-text-muted hover:text-brand hover:bg-brand-light rounded transition-colors"
                                             title="Consultar"
                                           >
                                             <Search size={14} />
                                           </button>
                                           {userRole === 'admin' && (
                                             <>
                                               <button 
                                                 onClick={() => {
                                                   setSelectedOferta({...o});
                                                   setShowEditOferta(true);
                                                 }}
                                                 className="p-1.5 text-text-muted hover:text-blue-600 hover:bg-blue-50 rounded transition-colors"
                                                 title="Modificar"
                                               >
                                                 <Edit2 size={14} />
                                               </button>
                                               <button 
                                                 onClick={() => {
                                                   setOfertaToCancel(o);
                                                   setShowCancelOfertaModal(true);
                                                 }}
                                                 className="p-1.5 text-text-muted hover:text-red-500 hover:bg-red-50 rounded transition-colors"
                                                 title="Cancelar"
                                               >
                                                 <XCircle size={14} />
                                               </button>
                                             </>
                                           )}
                                         </div>
                                       </td>
                                     </tr>
                                   );
                                })}
                              </tbody>
                            </table>
                          </div>
                        </div>
                      ) : null}

                      {activeTab === 'monitores' && (
                        <div className="space-y-6">
                           <div className="flex justify-between items-center mb-6">
                            <h4 className="text-sm font-bold text-text-main">Personal de Monitores</h4>
                             <button 
                              onClick={() => setShowMonitorModal(true)}
                              className="px-4 py-2 bg-brand text-white text-xs font-bold rounded-lg hover:opacity-90 transition-all flex items-center gap-2"
                            >
                              <Plus size={16} />
                              Registrar
                            </button>
                          </div>
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            {monitores.map((m) => (
                              <div key={m.id} className="p-4 border border-border-subtle rounded-xl bg-page/50 flex flex-col gap-3">
                                <div className="flex justify-between items-start">
                                  <div className="w-10 h-10 bg-white border border-border-subtle rounded-lg flex items-center justify-center text-xs font-bold text-brand">
                                    {m.nombre.split(' ').map(n => n[0]).join('')}
                                  </div>
                                  <div className="flex items-center gap-2">
                                    <div className="flex items-center gap-1">
                                      <button 
                                        onClick={() => {
                                          setSelectedMonitor(m);
                                          setShowDetailMonitor(true);
                                        }}
                                        className="p-1 text-text-muted hover:text-brand"
                                        title="Consultar"
                                      >
                                        <Search size={14} />
                                      </button>
                                      <button 
                                        onClick={() => {
                                          setSelectedMonitor({...m});
                                          setShowEditMonitor(true);
                                        }}
                                        className="p-1 text-text-muted hover:text-blue-600"
                                        title="Modificar"
                                      >
                                        <Edit2 size={14} />
                                      </button>
                                    </div>
                                    <span className={cn(
                                      "px-2 py-0.5 rounded text-[10px] font-bold uppercase",
                                      m.estado === 'Activo' ? "bg-green-100 text-green-700" : "bg-red-100 text-red-600"
                                    )}>
                                      {m.estado}
                                    </span>
                                  </div>
                                </div>
                                <div>
                                  <h5 className="font-bold text-[14px] text-text-main">{m.nombre}</h5>
                                  <p className="text-[11px] text-text-muted font-medium">{m.programa}</p>
                                </div>
                                <div className="p-2 bg-white rounded-lg border border-border-subtle flex justify-between items-center text-[11px]">
                                   <div className="text-center px-1">
                                     <p className="text-text-muted font-bold uppercase text-[9px]">Prom</p>
                                     <p className="font-bold text-brand">{m.promedio}</p>
                                   </div>
                                    <div className="w-px h-6 bg-border-subtle" />
                                   <div className="text-center px-1">
                                     <p className="text-text-muted font-bold uppercase text-[9px]">Horas</p>
                                     <p className="font-bold text-brand">{m.horasCumplidas}h</p>
                                   </div>
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}

                      {activeTab === 'validacion' && (
                        <div className="space-y-6">
                           <div className="flex justify-between items-center mb-6">
                            <h4 className="text-sm font-bold text-text-main">Validación de Horas de Monitoría</h4>
                            <div className="text-[10px] font-bold text-text-muted bg-border-subtle px-2 py-1 rounded">PENDIENTES: 12 HORAS</div>
                          </div>
                          <div className="space-y-4">
                            {[
                              { monitor: 'Juan Pérez', subject: 'Estructuras de Datos I', date: '15 de Abril, 2026', hours: '2h', students: 15, status: 'Pendiente' },
                              { monitor: 'Raúl Mesa', subject: 'Cálculo Diferencial', date: '16 de Abril, 2026', hours: '2h', students: 12, status: 'Pendiente' },
                              { monitor: 'Lucía Cano', subject: 'Física Mecánica', date: '14 de Abril, 2026', hours: '2h', students: 8, status: 'Aprobado' },
                              { monitor: 'Andrés López', subject: 'Cálculo Diferencial', date: '13 de Abril, 2026', hours: '2h', students: 10, status: 'Pendiente' },
                            ].map((item, i) => (
                              <div key={i} className="p-4 border border-border-subtle rounded-xl bg-white hover:border-brand/30 transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                                <div className="flex items-center gap-3">
                                  <div className="w-10 h-10 bg-brand-light text-brand rounded-lg flex items-center justify-center font-bold text-sm">
                                    {item.monitor.charAt(0)}
                                  </div>
                                  <div>
                                    <p className="text-sm font-bold text-text-main leading-tight">{item.subject}</p>
                                    <p className="text-[11px] text-text-muted">Monitor: <b>{item.monitor}</b> • {item.date}</p>
                                  </div>
                                </div>
                                <div className="flex items-center justify-between sm:justify-end gap-6 border-t sm:border-t-0 pt-3 sm:pt-0 border-border-subtle/50">
                                  <div className="text-center">
                                    <p className="text-[9px] uppercase font-bold text-text-muted leading-tight">Horas</p>
                                    <p className="text-xs font-bold text-brand">{item.hours}</p>
                                  </div>
                                  <div className="text-center">
                                    <p className="text-[9px] uppercase font-bold text-text-muted leading-tight">Asistencia</p>
                                    <p className="text-xs font-bold text-text-main">{item.students}</p>
                                  </div>
                                  {item.status === 'Pendiente' ? (
                                    <button 
                                      onClick={() => alert('Sesión validada y certificada exitosamente. Se ha notificado al monitor.')}
                                      className="px-4 py-2 bg-brand text-white text-[10px] font-bold rounded-lg hover:bg-brand/90 transition-all uppercase tracking-wider"
                                    >
                                      Validar
                                    </button>
                                  ) : (
                                    <div className="flex items-center gap-1.5 text-green-600 font-bold text-[10px] uppercase bg-green-50 px-3 py-2 rounded-lg border border-green-100">
                                      <CheckCircle2 size={14} />
                                      Validado
                                    </div>
                                  )}
                                </div>
                              </div>
                            ))}
                          </div>
                          <div className="p-4 bg-orange-50 border border-orange-100 rounded-xl flex items-start gap-3">
                             <Activity className="text-orange-600 shrink-0" size={18} />
                             <p className="text-[11px] text-orange-800 leading-relaxed">
                               <b>Recordatorio:</b> Las horas validadas antes del día 20 de cada mes serán procesadas para el corte actual. 
                               Por favor, revise con cuidado la asistencia reportada por el monitor.
                             </p>
                          </div>
                        </div>
                      )}

                      {activeTab === 'reportes' && (
                        <div className="space-y-8">
                           <div className="flex justify-between items-center mb-6">
                            <h4 className="text-sm font-bold text-text-main">
                              {userRole === 'admin' ? 'Analítica de Gestión' : 'Mi Reporte de Actividad'}
                            </h4>
                             <button 
                              disabled={isExporting}
                              onClick={() => {
                                setIsExporting(true);
                                setTimeout(() => {
                                  setIsExporting(false);
                                  setExportSuccess(true);
                                  setTimeout(() => setExportSuccess(false), 3000);
                                }, 2000);
                              }}
                              className={cn(
                                "px-4 py-2 text-xs font-bold rounded-lg transition-all flex items-center gap-2",
                                isExporting ? "bg-gray-100 text-gray-400 cursor-not-allowed" : "bg-white border border-brand text-brand hover:bg-brand-light"
                              )}
                            >
                              {isExporting ? (
                                <>
                                  <div className="w-3 h-3 border-2 border-brand border-t-transparent rounded-full animate-spin" />
                                  Exportando...
                                </>
                              ) : "Exportar Datos"}
                            </button>
                          </div>
                          {exportSuccess && (
                            <div className="p-3 bg-green-50 border border-green-200 text-green-700 text-xs font-bold rounded-lg flex items-center gap-2 mb-4 animate-in fade-in slide-in-from-top-2">
                              <CheckCircle2 size={16} />
                              Reporte exportado como PDF/Excel con éxito.
                            </div>
                          )}
                          <div className="h-[300px] w-full">
                            <ResponsiveContainer width="100%" height="100%">
                              <BarChart data={userRole === 'admin' ? reportData : [
                                { name: 'Sem 1', sesiones: 8 },
                                { name: 'Sem 2', sesiones: 12 },
                                { name: 'Sem 3', sesiones: 15 },
                                { name: 'Sem 4', sesiones: 10 },
                                { name: 'Sem 5', sesiones: 18 },
                              ]}>
                                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fontSize: 10, fill: '#64748b', fontWeight: 600 }} />
                                <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 10, fill: '#64748b', fontWeight: 600 }} />
                                <Tooltip 
                                  contentStyle={{ borderRadius: '8px', border: '1px solid #e2e8f0', fontSize: '12px' }}
                                />
                                <Bar dataKey="sesiones" fill="#15803d" radius={[4, 4, 0, 0]} barSize={40} />
                              </BarChart>
                            </ResponsiveContainer>
                          </div>
                          {userRole === 'monitor' && (
                            <div className="grid grid-cols-2 gap-4">
                              <div className="p-4 bg-brand-light/20 border border-brand/10 rounded-xl">
                                <p className="text-[10px] font-bold text-brand uppercase mb-1">Total Horas</p>
                                <p className="text-xl font-black text-brand">{currentMonitor.horasCumplidas} Horas</p>
                              </div>
                              <div className="p-4 bg-orange-50 border border-orange-100 rounded-xl">
                                <p className="text-[10px] font-bold text-orange-600 uppercase mb-1">Promedio Estudiantes</p>
                                <p className="text-xl font-black text-orange-600">4.5 / Sesión</p>
                              </div>
                            </div>
                          )}
                        </div>
                      )}

                      {activeTab === 'reserva' && (
                        <div className="space-y-6">
                          <div className="flex justify-between items-center mb-4">
                            <h4 className="text-sm font-bold text-text-main">Disponibilidad para Reserva</h4>
                            <div className="flex items-center gap-2">
                              <Search size={14} className="text-text-muted" />
                              <input 
                                type="text" 
                                placeholder="Buscar asignatura..." 
                                className="bg-page border border-border-subtle rounded px-2 py-1 text-xs focus:ring-1 focus:ring-brand outline-none"
                              />
                            </div>
                          </div>
                          {bookingSuccess && (
                            <div className="p-3 bg-green-50 border border-green-200 text-green-700 text-xs font-bold rounded-lg flex items-center gap-2 mb-4">
                              <CheckCircle2 size={16} />
                              Reserva confirmada con éxito para {bookingSuccess}
                            </div>
                          )}
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            {ofertas.map((o) => {
                              const subject = DUMMY_ASIGNATURAS.find(s => s.id === o.asignaturaId);
                              const monitor = monitores.find(m => m.id === o.monitorId);
                              return (
                                <div key={o.id} className="p-4 border border-border-subtle rounded-xl bg-page/50 group hover:bg-white transition-all">
                                  <div className="flex justify-between items-start mb-2">
                                    <h5 className="font-bold text-[14px] text-text-main">{subject?.nombre}</h5>
                                    <div className="flex items-center gap-1 text-[10px] font-bold text-text-muted bg-border-subtle px-2 py-0.5 rounded">
                                      {o.cuposMax - o.cuposReservados} cupos
                                    </div>
                                  </div>
                                  <div className="space-y-2 mb-4">
                                    <div className="flex items-center gap-2 text-[11px] text-text-muted">
                                      <Users size={12} className="text-brand" />
                                      <span>Monitor: <b>{monitor?.nombre}</b></span>
                                    </div>
                                    <div className="flex items-center gap-2 text-[11px] text-text-muted">
                                      <Clock size={12} className="text-brand" />
                                      <span>{o.horario}</span>
                                    </div>
                                    <div className="flex items-center gap-2 text-[11px] text-text-muted">
                                      <MapPin size={12} className="text-brand" />
                                      <span>Aula: {o.aula}</span>
                                    </div>
                                  </div>
                                  <button 
                                    onClick={() => {
                                      const updated = ofertas.map(item => item.id === o.id ? {...item, cuposReservados: item.cuposReservados + 1} : item);
                                      setOfertas(updated);
                                      
                                      const nuevaReserva: Reserva = {
                                        id: `RES-${Date.now()}`,
                                        ofertaId: o.id,
                                        estudianteNombre: "Director de Depto (Demo)",
                                        estudianteEmail: "jhoan.chavez@correounivalle.edu.co",
                                        fecha: new Date().toISOString(),
                                        asistencia: null
                                      };
                                      setReservasRealizadas([nuevaReserva, ...reservasRealizadas]);
                                      
                                      setBookingSuccess(subject?.nombre || 'la sesión');
                                      setTimeout(() => setBookingSuccess(null), 3000);
                                    }}
                                    className="w-full py-2 bg-brand text-white text-[10px] font-bold rounded-lg hover:opacity-90 transition-all flex items-center justify-center gap-2 uppercase tracking-tight"
                                  >
                                    <CalendarCheck size={14} />
                                    Reservar Cupo
                                  </button>
                                </div>
                              );
                            })}
                          </div>

                          {reservasRealizadas.length > 0 && (
                            <div className="mt-10 pt-10 border-t border-border-subtle">
                               <h4 className="text-sm font-bold text-text-main mb-4 flex items-center gap-2">
                                 <CalendarCheck size={16} className="text-brand" />
                                 Mis Reservas Confirmadas
                               </h4>
                               <div className="space-y-3">
                                 {reservasRealizadas.map((res) => {
                                   const oferta = ofertas.find(of => of.id === res.ofertaId);
                                   const subject = DUMMY_ASIGNATURAS.find(s => s.id === oferta?.asignaturaId);
                                   const monitor = monitores.find(m => m.id === oferta?.monitorId);
                                   return (
                                     <div key={res.id} className="flex flex-col sm:flex-row sm:items-center justify-between p-4 bg-white border border-border-subtle rounded-xl gap-4">
                                       <div className="flex items-center gap-4">
                                         <div className="w-10 h-10 bg-brand-light text-brand rounded-lg flex items-center justify-center shrink-0">
                                           <GraduationCap size={20} />
                                         </div>
                                         <div>
                                           <div className="flex items-center gap-2">
                                             <p className="text-sm font-bold text-text-main">{subject?.nombre}</p>
                                             <span className="text-[10px] font-bold text-text-muted bg-page px-2 py-0.5 rounded border border-border-subtle">ID: {res.id}</span>
                                           </div>
                                           <p className="text-[11px] text-text-muted">Monitor: <b>{monitor?.nombre}</b> • {oferta?.horario}</p>
                                         </div>
                                       </div>
                                       <div className="flex items-center gap-3 shrink-0">
                                          <div className="text-right">
                                            <p className="text-[10px] uppercase font-bold text-text-muted leading-tight">Estado</p>
                                            <p className="text-[11px] font-bold text-brand italic">Confirmado</p>
                                          </div>
                                          <button 
                                            onClick={() => {
                                              if(confirm('¿Desea cancelar esta reserva?')) {
                                                setReservasRealizadas(reservasRealizadas.filter(r => r.id !== res.id));
                                                setOfertas(ofertas.map(of => of.id === res.ofertaId ? {...of, cuposReservados: Math.max(0, of.cuposReservados - 1)} : of));
                                              }
                                            }}
                                            className="p-2 hover:bg-red-50 text-red-400 hover:text-red-500 rounded-lg transition-colors border border-transparent hover:border-red-100"
                                            title="Cancelar Reserva"
                                          >
                                            <XCircle size={18} />
                                          </button>
                                       </div>
                                     </div>
                                   );
                                 })}
                               </div>
                            </div>
                          )}
                        </div>
                      )}

                      {activeTab === 'asistencia' && (
                        <div className="space-y-6">
                           <div className="flex justify-between items-center mb-6">
                            <h4 className="text-sm font-bold text-text-main">Control de Asistencia</h4>
                            <div className="text-xs font-bold text-text-muted">ID Sesión: #ACT-4421</div>
                          </div>
                          
                          {isSessionActive ? (
                            <div className="bg-brand-light/20 p-4 rounded-xl border border-brand/10 mb-6 flex items-center justify-between">
                              <div className="flex items-center gap-4">
                                <div className="w-10 h-10 bg-brand text-white rounded-lg flex items-center justify-center">
                                  <ClipboardCheck size={20} />
                                </div>
                                <div>
                                  <p className="text-xs font-bold text-brand">Sesión en curso</p>
                                  <p className="text-sm font-bold text-text-main">
                                    {userRole === 'admin' 
                                      ? 'Estructuras de Datos I - Juan Pérez (Simulación)' 
                                      : `${ofertas.find(o => o.monitorId === currentMonitor.id)?.asignaturaId === 'ASIG-2' ? 'Estructuras de Datos I' : 'Cálculo Diferencial'} - ${currentMonitor.nombre}`
                                    }
                                  </p>
                                </div>
                              </div>
                              <button 
                                onClick={() => {
                                  if(confirm('¿Está seguro de que desea cerrar la sesión actual? Se guardará el registro de asistencia.')) {
                                    setIsSessionActive(false);
                                  }
                                }}
                                className="px-3 py-1.5 bg-brand text-white text-[10px] font-bold rounded-lg hover:bg-brand/90 transition-colors"
                              >
                                Cerrar Sesión
                              </button>
                            </div>
                          ) : (
                            <div className="bg-gray-50 p-4 rounded-xl border border-border-subtle mb-6 flex items-center justify-between">
                              <div className="flex items-center gap-4">
                                <div className="w-10 h-10 bg-gray-200 text-gray-400 rounded-lg flex items-center justify-center">
                                  <XCircle size={20} />
                                </div>
                                <div>
                                  <p className="text-xs font-bold text-gray-500">Sesión Finalizada</p>
                                  <p className="text-sm font-bold text-gray-400">El registro de asistencia ha sido guardado.</p>
                                </div>
                              </div>
                              <button 
                                onClick={() => setIsSessionActive(true)}
                                className="px-3 py-1.5 bg-white border border-brand text-brand text-[10px] font-bold rounded-lg"
                              >
                                Reabrir (Demo)
                              </button>
                            </div>
                          )}

                          <div className={cn("space-y-2", !isSessionActive && "opacity-50 pointer-events-none")}>
                             {asistenciaHoy.map((student) => (
                               <div key={student.id} className="flex items-center justify-between p-3 border border-border-subtle rounded-lg bg-page/30">
                                 <div className="flex items-center gap-3">
                                   <div className="w-8 h-8 rounded-full bg-border-subtle flex items-center justify-center text-[10px] font-bold">
                                     {student.name.charAt(0)}
                                   </div>
                                   <div>
                                     <p className="text-[12px] font-bold text-text-main">{student.name}</p>
                                     <p className="text-[10px] text-text-muted">{student.email}</p>
                                   </div>
                                 </div>
                                 <div className="flex items-center gap-2">
                                   <button 
                                     onClick={() => setAsistenciaHoy(curr => curr.map(s => s.id === student.id ? {...s, status: 'Presente'} : s))}
                                     className={cn(
                                       "px-2 py-1 rounded text-[9px] font-bold uppercase transition-all",
                                       student.status === 'Presente' ? "bg-green-100 text-green-700 border border-green-200" : "bg-border-subtle text-text-muted border border-transparent hover:bg-gray-200"
                                     )}
                                   >
                                     Presente
                                   </button>
                                   <button 
                                     onClick={() => setAsistenciaHoy(curr => curr.map(s => s.id === student.id ? {...s, status: 'Ausente'} : s))}
                                     className={cn(
                                       "px-2 py-1 rounded text-[9px] font-bold uppercase transition-all",
                                       student.status === 'Ausente' ? "bg-red-100 text-red-700 border border-red-200" : "bg-border-subtle text-text-muted border border-transparent hover:bg-gray-200"
                                     )}
                                   >
                                     Ausente
                                   </button>
                                 </div>
                               </div>
                             ))}
                          </div>
                        </div>
                      )}

                      {activeTab === 'contactos' && (
                        <div className="space-y-6">
                           <SectionHeader 
                            title="Soporte y Contactos" 
                            desc="Preguntas frecuentes y soporte técnico de la plataforma SIGMON." 
                          />
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                             {[
                               { role: 'Soporte Técnico', name: 'Ing. Carlos Mendoza', email: 'soporte.sigmon@univalle.edu.co', phone: '+57 300 000 0000' },
                               { role: 'Dirección Académica', name: 'Dra. Elena Gomez', email: 'direccion.academica@univalle.edu.co', phone: 'Ext. 4021' },
                               { role: 'Bienestar Estudiantil', name: 'Lic. Martha Perez', email: 'bienestar.est@univalle.edu.co', phone: 'Ext. 1105' },
                               { role: 'Administración de Aulas', name: 'David Torres', email: 'aulas.adm@univalle.edu.co', phone: 'Ext. 9901' },
                             ].map((c, i) => (
                               <div key={i} className="p-4 border border-border-subtle rounded-xl bg-page/50">
                                 <p className="text-[10px] font-bold text-brand uppercase mb-1">{c.role}</p>
                                 <h5 className="font-bold text-text-main mb-2">{c.name}</h5>
                                 <div className="space-y-1 text-[11px] text-text-muted">
                                   <p className="flex items-center gap-2 underline">{c.email}</p>
                                   <p>{c.phone}</p>
                                 </div>
                               </div>
                             ))}
                          </div>
                          <div className="p-4 bg-brand-light/30 border border-brand/20 rounded-xl">
                            <h5 className="text-xs font-bold text-brand mb-2 italic">¿Necesitas ayuda inmediata?</h5>
                            <p className="text-[11px] text-text-main leading-relaxed">
                              El sistema de tickets está activo de Lunes a Viernes de 8:00 AM a 6:00 PM. 
                              Las solicitudes realizadas fuera de este horario serán atendidas el siguiente día hábil.
                            </p>
                          </div>
                        </div>
                      )}

                      {activeTab === 'configuracion' && (
                        <div className="space-y-8">
                           <SectionHeader 
                            title="Configuración del Sistema" 
                            desc="Ajustes globales y gestión del semestre activo." 
                          />
                          <div className="space-y-6">
                            <div className="p-5 border border-border-subtle rounded-xl bg-page/20">
                              <h5 className="text-xs font-bold text-text-main mb-4 flex items-center gap-2">
                                <Calendar size={14} className="text-brand" />
                                Periodo Académico
                              </h5>
                              <div className="grid grid-cols-2 gap-4">
                                <div>
                                  <label className="text-[10px] font-bold text-text-muted uppercase mb-1 block">Semestre Activo</label>
                                  <select className="w-full bg-white border border-border-subtle rounded px-3 py-2 text-[12px] font-bold text-text-main outline-none focus:ring-1 focus:ring-brand">
                                    <option>2026-1</option>
                                    <option>2025-2</option>
                                    <option>2025-1</option>
                                  </select>
                                </div>
                                <div>
                                  <label className="text-[10px] font-bold text-text-muted uppercase mb-1 block">Estado</label>
                                  <div className="flex items-center gap-2 mt-2">
                                    <div className="w-8 h-4 bg-brand rounded-full relative">
                                      <div className="absolute right-0.5 top-0.5 w-3 h-3 bg-white rounded-full" />
                                    </div>
                                    <span className="text-[11px] font-bold text-brand">ACTIVO</span>
                                  </div>
                                </div>
                              </div>
                            </div>

                            <div className="p-5 border border-border-subtle rounded-xl bg-page/20">
                              <h5 className="text-xs font-bold text-text-main mb-4 flex items-center gap-2">
                                <Users size={14} className="text-brand" />
                                Permisos y Roles
                              </h5>
                              <div className="space-y-3">
                                {['Administrador', 'Monitor', 'Catedrático', 'Estudiante'].map((role, i) => (
                                  <div key={i} className="flex justify-between items-center p-2 bg-white rounded-lg border border-border-subtle">
                                    <span className="text-xs font-bold text-text-main">{role}</span>
                                    <button className="text-[10px] font-bold text-brand hover:underline">Ver Permisos</button>
                                  </div>
                                ))}
                              </div>
                            </div>
                          </div>
                          <button 
                            onClick={() => {
                              alert('Configuración guardada correctamente.');
                            }}
                            className="w-full py-3 bg-brand text-white font-bold rounded-xl text-xs uppercase tracking-widest shadow-lg shadow-brand/20">
                            Guardar Cambios
                          </button>
                        </div>
                      )}

                      {!['inicio', 'oferta', 'monitores', 'reportes', 'reserva', 'asistencia', 'contactos', 'configuracion'].includes(activeTab) && (
                        <div className="py-20 flex flex-col items-center justify-center text-center opacity-60">
                           <div className="mb-4 text-text-muted">
                             {menuItems.find(i => i.id === activeTab)?.icon && React.cloneElement(menuItems.find(i => i.id === activeTab)?.icon as React.ReactElement, { size: 48, strokeWidth: 1.5 })}
                           </div>
                           <h4 className="text-sm font-bold text-text-main mb-1">Módulo "{menuItems.find(i => i.id === activeTab)?.title}"</h4>
                           <p className="text-xs text-text-muted">Desarrollo de interfaz pendiente para este módulo secundario.</p>
                        </div>
                      )}
                    </div>
                  </div>

                  <div className="space-y-6">
                    <div className="bg-white rounded-xl border border-border-subtle p-5">
                      <h4 className="text-[11px] font-bold text-text-muted uppercase tracking-widest mb-4">Atajos Rápidos</h4>
                      <div className="space-y-3">
                        {userRole === 'admin' && (
                          <button 
                            onClick={() => setShowCSVModal(true)}
                            className="w-full py-2.5 bg-brand text-white text-xs font-bold rounded-lg hover:opacity-95 transition-all text-center"
                          >
                            Cargar CSV de Asignaturas
                          </button>
                        )}
                        {userRole === 'monitor' && (
                          <button 
                            onClick={() => setShowMonitorReportModal(true)}
                            className="w-full py-2.5 bg-brand text-white text-xs font-bold rounded-lg hover:opacity-95 transition-all text-center"
                          >
                            Descargar Reporte Mensual
                          </button>
                        )}
                        {userRole === 'estudiante' && (
                          <button 
                            onClick={() => setActiveTab('reserva')}
                            className="w-full py-2.5 bg-brand text-white text-xs font-bold rounded-lg hover:opacity-95 transition-all text-center"
                          >
                            Buscar Horarios Disponibles
                          </button>
                        )}
                        {userRole === 'catedratico' && (
                          <button 
                            onClick={() => setShowDocenteReportModal(true)}
                            className="w-full py-2.5 bg-brand text-white text-xs font-bold rounded-lg hover:opacity-95 transition-all text-center"
                          >
                            Descargar Informe Docente
                          </button>
                        )}
                        <button 
                          onClick={() => {
                            if (userRole === 'estudiante') {
                              setActiveTab('reserva');
                              setTimeout(() => alert('Tus reservas confirmadas se encuentran en la sección inferior de esta vista.'), 100);
                            } else if (userRole === 'catedratico') {
                               setShowDecanaturaModal(true);
                            } else {
                              setShowCertModal(true);
                            }
                          }}
                          className="w-full py-2.5 bg-white border border-brand text-brand text-xs font-bold rounded-lg hover:bg-brand-light transition-all text-center"
                        >
                          {userRole === 'admin' ? 'Generar Certificados' : userRole === 'monitor' ? 'Mi Certificado Digital' : userRole === 'catedratico' ? 'Enviar Reporte a Decanatura' : 'Consultar Mis Reservas'}
                        </button>
                      </div>
                    </div>

                    <div className="bg-white rounded-xl border border-border-subtle p-5">
                      <h4 className="text-[11px] font-bold text-text-muted uppercase tracking-widest mb-5">Monitores Destacados</h4>
                      <div className="space-y-4">
                        {[
                          { name: 'Juan Pérez', career: 'Sistemas', code: 'JP' },
                          { name: 'Lucía Cano', career: 'Civil', code: 'LC' },
                          { name: 'Raúl Mesa', career: 'Ind.', code: 'RM' },
                        ].map((m, i) => (
                          <div key={i} className="flex items-center gap-3">
                            <div className="w-8 h-8 bg-border-subtle rounded-full flex items-center justify-center text-[10px] font-bold text-slate-600">
                              {m.code}
                            </div>
                            <div className="flex-grow">
                              <p className="text-[12px] font-bold text-text-main leading-tight">{m.name}</p>
                              <p className="text-[10px] text-text-muted font-medium">{m.career}</p>
                            </div>
                            <div className="w-2 h-2 bg-[#22c55e] rounded-full" />
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
            </motion.div>
          </AnimatePresence>
        </div>
      </div>
    </main>

    {/* Modals */}
      <Modal isOpen={showOfertaModal} onClose={() => setShowOfertaModal(false)} title="Ingresar Nueva Oferta">
        <div className="space-y-4">
          <div>
            <label className="text-[10px] font-bold text-text-muted uppercase block mb-1">Asignatura</label>
            <select 
              value={newOferta.asignaturaId}
              onChange={(e) => setNewOferta({...newOferta, asignaturaId: e.target.value})}
              className="w-full p-2 border border-border-subtle rounded-lg text-sm bg-page"
            >
              <option value="">Seleccione Asignatura...</option>
              {DUMMY_ASIGNATURAS.map(a => <option key={a.id} value={a.id}>{a.nombre}</option>)}
            </select>
          </div>
          <div>
            <label className="text-[10px] font-bold text-text-muted uppercase block mb-1">Monitor</label>
            <select 
              value={newOferta.monitorId}
              onChange={(e) => setNewOferta({...newOferta, monitorId: e.target.value})}
              className="w-full p-2 border border-border-subtle rounded-lg text-sm bg-page"
            >
              <option value="">Seleccione Monitor...</option>
              {monitores.map(m => <option key={m.id} value={m.id}>{m.nombre}</option>)}
            </select>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="text-[10px] font-bold text-text-muted uppercase block mb-1">Horario</label>
              <input 
                type="text" 
                placeholder="Ej: Lunes 14:00" 
                value={newOferta.horario}
                onChange={(e) => setNewOferta({...newOferta, horario: e.target.value})}
                className="w-full p-2 border border-border-subtle rounded-lg text-sm bg-page" 
              />
            </div>
            <div>
              <label className="text-[10px] font-bold text-text-muted uppercase block mb-1">Aula</label>
              <input 
                type="text" 
                placeholder="Ej: Aula 401" 
                value={newOferta.aula}
                onChange={(e) => setNewOferta({...newOferta, aula: e.target.value})}
                className="w-full p-2 border border-border-subtle rounded-lg text-sm bg-page" 
              />
            </div>
          </div>
          <button 
            onClick={handleCreateOferta}
            className="w-full py-3 bg-brand text-white font-bold rounded-lg text-sm uppercase tracking-widest mt-4"
          >
            Confirmar Oferta
          </button>
        </div>
      </Modal>

      <Modal isOpen={showMonitorModal} onClose={() => setShowMonitorModal(false)} title="Registrar Estudiante Monitor">
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="text-[10px] font-bold text-text-muted uppercase block mb-1">Nombre Completo</label>
              <input 
                type="text" 
                placeholder="Nombre del estudiante" 
                value={newMonitor.nombre}
                onChange={(e) => setNewMonitor({...newMonitor, nombre: e.target.value})}
                className="w-full p-2 border border-border-subtle rounded-lg text-sm bg-page" 
              />
            </div>
            <div>
              <label className="text-[10px] font-bold text-text-muted uppercase block mb-1">Email Institucional</label>
              <input 
                type="email" 
                placeholder="usuario@univalle.edu.co" 
                value={newMonitor.email}
                onChange={(e) => setNewMonitor({...newMonitor, email: e.target.value})}
                className="w-full p-2 border border-border-subtle rounded-lg text-sm bg-page" 
              />
            </div>
          </div>
          <div>
            <label className="text-[10px] font-bold text-text-muted uppercase block mb-1">Programa Académico</label>
            <input 
              type="text" 
              placeholder="Sistemas, Civil, etc." 
              value={newMonitor.programa}
              onChange={(e) => setNewMonitor({...newMonitor, programa: e.target.value})}
              className="w-full p-2 border border-border-subtle rounded-lg text-sm bg-page" 
            />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="text-[10px] font-bold text-text-muted uppercase block mb-1">Promedio</label>
              <input 
                type="number" 
                step="0.1" 
                placeholder="4.5" 
                value={newMonitor.promedio}
                onChange={(e) => setNewMonitor({...newMonitor, promedio: e.target.value})}
                className="w-full p-2 border border-border-subtle rounded-lg text-sm bg-page" 
              />
            </div>
            <div>
              <label className="text-[10px] font-bold text-text-muted uppercase block mb-1">Asignatura Principal</label>
              <input 
                type="text" 
                placeholder="Materia favorita" 
                value={newMonitor.asignaturaPrincipal}
                onChange={(e) => setNewMonitor({...newMonitor, asignaturaPrincipal: e.target.value})}
                className="w-full p-2 border border-border-subtle rounded-lg text-sm bg-page" 
              />
            </div>
          </div>
          <button 
            onClick={handleCreateMonitor}
            className="w-full py-3 bg-brand text-white font-bold rounded-lg text-sm uppercase tracking-widest mt-4"
          >
            Vincular Monitores
          </button>
        </div>
      </Modal>

      <Modal isOpen={showCSVModal} onClose={() => setShowCSVModal(false)} title="Cargar CSV de Asignaturas">
        <div className="space-y-6 flex flex-col items-center py-4">
          <div className="w-20 h-20 bg-brand-light rounded-full flex items-center justify-center border-2 border-dashed border-brand/50">
             <FileText size={32} className="text-brand" />
          </div>
          <div className="text-center">
            <p className="text-sm font-bold text-text-main">Seleccione el archivo .csv</p>
            <p className="text-[11px] text-text-muted">Formato: CODIGO, NOMBRE, FACULTAD, CREDITOS</p>
          </div>
          <input type="file" className="text-xs text-text-muted border border-border-subtle p-2 rounded w-full" />
          <button 
            onClick={handleCSVUpload}
            className="w-full py-3 bg-brand text-white font-bold rounded-lg text-sm uppercase tracking-widest"
          >
            Iniciar Carga
          </button>
        </div>
      </Modal>

      <Modal isOpen={showCertModal} onClose={() => setShowCertModal(false)} title="Generar Certificados de Monitoria">
        <div className="space-y-4">
          <p className="text-[11px] text-text-muted">
            {userRole === 'admin' 
              ? 'Seleccione el monitor para generar el certificado de cumplimiento de horas.' 
              : 'Descargue su certificado oficial de cumplimiento de actividades de monitoria.'}
          </p>
          {userRole === 'admin' ? (
            <select className="w-full p-2 border border-border-subtle rounded-lg text-sm bg-page">
              {monitores.map(m => <option key={m.id}>{m.nombre} - {m.horasCumplidas}h</option>)}
            </select>
          ) : (
            <div className="p-3 bg-brand-light/30 border border-brand/20 rounded-lg flex items-center gap-3">
              <div className="w-10 h-10 bg-brand text-white rounded flex items-center justify-center font-bold">
                {currentMonitor.nombre.substring(0, 2).toUpperCase()}
              </div>
              <div>
                <p className="text-xs font-bold text-text-main">{currentMonitor.nombre}</p>
                <p className="text-[10px] text-brand font-bold">{currentMonitor.horasCumplidas} Horas Reportadas</p>
              </div>
            </div>
          )}
          <div className="p-3 bg-page rounded-xl border border-border-subtle flex flex-col gap-2">
            <div className="flex justify-between text-[11px] font-bold">
              <span className="text-text-muted uppercase">Tipo Reporte</span>
              <span className="text-text-main">Excel/PDF</span>
            </div>
            <div className="flex justify-between text-[11px] font-bold">
              <span className="text-text-muted uppercase">Firma Digital</span>
              <span className="text-brand">HABILITADA</span>
            </div>
          </div>
          <button 
            onClick={handleCertGenerate}
            className="w-full py-3 bg-brand text-white font-bold rounded-lg text-sm uppercase tracking-widest mt-4"
          >
            Generar y Descargar
          </button>
        </div>
      </Modal>

      <Modal isOpen={showEditOferta} onClose={() => setShowEditOferta(false)} title="Modificar Oferta de Monitoría">
        {selectedOferta && (
          <form onSubmit={handleUpdateOferta} className="space-y-4">
            <div>
              <label className="text-[10px] font-bold text-text-muted uppercase block mb-1">Asignatura</label>
              <select 
                value={selectedOferta.asignaturaId}
                onChange={(e) => setSelectedOferta({...selectedOferta, asignaturaId: e.target.value})}
                className="w-full p-2 border border-border-subtle rounded-lg text-sm bg-page"
                required
              >
                {DUMMY_ASIGNATURAS.map(a => <option key={a.id} value={a.id}>{a.nombre}</option>)}
              </select>
            </div>
            <div>
              <label className="text-[10px] font-bold text-text-muted uppercase block mb-1">Monitor</label>
              <select 
                value={selectedOferta.monitorId}
                onChange={(e) => setSelectedOferta({...selectedOferta, monitorId: e.target.value})}
                className="w-full p-2 border border-border-subtle rounded-lg text-sm bg-page"
                required
              >
                {monitores.map(m => <option key={m.id} value={m.id}>{m.nombre}</option>)}
              </select>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-[10px] font-bold text-text-muted uppercase block mb-1">Horario</label>
                <input 
                  type="text" 
                  value={selectedOferta.horario}
                  onChange={(e) => setSelectedOferta({...selectedOferta, horario: e.target.value})}
                  className="w-full p-2 border border-border-subtle rounded-lg text-sm bg-page" 
                  required
                />
              </div>
              <div>
                <label className="text-[10px] font-bold text-text-muted uppercase block mb-1">Aula</label>
                <input 
                  type="text" 
                  value={selectedOferta.aula}
                  onChange={(e) => setSelectedOferta({...selectedOferta, aula: e.target.value})}
                  className="w-full p-2 border border-border-subtle rounded-lg text-sm bg-page" 
                  required
                />
              </div>
            </div>
            <div>
              <label className="text-[10px] font-bold text-text-muted uppercase block mb-1">Estado</label>
              <select 
                value={selectedOferta.estado}
                onChange={(e) => setSelectedOferta({...selectedOferta, estado: e.target.value as any})}
                className="w-full p-2 border border-border-subtle rounded-lg text-sm bg-page"
              >
                <option value="Activo">Activo</option>
                <option value="Cancelado">Cancelado</option>
                <option value="Finalizado">Finalizado</option>
              </select>
            </div>
            <button 
              type="submit"
              className="w-full py-3 bg-brand text-white font-bold rounded-lg text-sm uppercase tracking-widest mt-4"
            >
              Guardar Cambios
            </button>
          </form>
        )}
      </Modal>

      <Modal isOpen={showDetailOferta} onClose={() => setShowDetailOferta(false)} title="Detalles de la Oferta">
        {selectedOferta && (
          <div className="space-y-4 py-2">
            <div className="p-4 bg-brand-light/20 rounded-xl border border-brand/10">
              <h5 className="text-xs font-bold text-brand uppercase mb-2">Información de la Clase</h5>
              <div className="space-y-2">
                <p className="text-sm font-bold text-text-main">
                  {DUMMY_ASIGNATURAS.find(a => a.id === selectedOferta.asignaturaId)?.nombre}
                </p>
                <p className="text-xs text-text-muted">
                  Código: <span className="font-bold">{DUMMY_ASIGNATURAS.find(a => a.id === selectedOferta.asignaturaId)?.codigo}</span>
                </p>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="p-4 bg-page rounded-xl border border-border-subtle">
                <h5 className="text-[10px] font-bold text-text-muted uppercase mb-2">Monitor Asignado</h5>
                <p className="text-sm font-bold text-text-main">
                  {monitores.find(m => m.id === selectedOferta.monitorId)?.nombre}
                </p>
              </div>
              <div className="p-4 bg-page rounded-xl border border-border-subtle">
                <h5 className="text-[10px] font-bold text-text-muted uppercase mb-2">Horario y Aula</h5>
                <p className="text-sm font-bold text-text-main">{selectedOferta.horario}</p>
                <p className="text-xs text-text-muted">{selectedOferta.aula}</p>
              </div>
            </div>
            <div className="p-4 bg-page rounded-xl border border-border-subtle flex justify-between items-center">
              <span className="text-[10px] font-bold text-text-muted uppercase">Cupos Reservados</span>
              <span className="text-sm font-bold text-brand">{selectedOferta.cuposReservados} / {selectedOferta.cuposMax}</span>
            </div>
          </div>
        )}
      </Modal>

      <Modal isOpen={showEditMonitor} onClose={() => setShowEditMonitor(false)} title="Modificar Información del Monitor">
        {selectedMonitor && (
          <form onSubmit={handleUpdateMonitor} className="space-y-4">
             <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-[10px] font-bold text-text-muted uppercase block mb-1">Nombre Completo</label>
                  <input 
                    type="text" 
                    value={selectedMonitor.nombre}
                    onChange={(e) => setSelectedMonitor({...selectedMonitor, nombre: e.target.value})}
                    className="w-full p-2 border border-border-subtle rounded-lg text-sm bg-page" 
                    required
                  />
                </div>
                <div>
                  <label className="text-[10px] font-bold text-text-muted uppercase block mb-1">Email</label>
                  <input 
                    type="email" 
                    value={selectedMonitor.email}
                    onChange={(e) => setSelectedMonitor({...selectedMonitor, email: e.target.value})}
                    className="w-full p-2 border border-border-subtle rounded-lg text-sm bg-page" 
                    required
                  />
                </div>
              </div>
              <div>
                <label className="text-[10px] font-bold text-text-muted uppercase block mb-1">Programa Académico</label>
                <input 
                  type="text" 
                  value={selectedMonitor.programa}
                  onChange={(e) => setSelectedMonitor({...selectedMonitor, programa: e.target.value})}
                  className="w-full p-2 border border-border-subtle rounded-lg text-sm bg-page" 
                  required
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-[10px] font-bold text-text-muted uppercase block mb-1">Promedio</label>
                  <input 
                    type="number" 
                    step="0.1"
                    value={selectedMonitor.promedio}
                    onChange={(e) => setSelectedMonitor({...selectedMonitor, promedio: parseFloat(e.target.value)})}
                    className="w-full p-2 border border-border-subtle rounded-lg text-sm bg-page" 
                    required
                  />
                </div>
                <div>
                  <label className="text-[10px] font-bold text-text-muted uppercase block mb-1">Estado</label>
                  <select 
                    value={selectedMonitor.estado}
                    onChange={(e) => setSelectedMonitor({...selectedMonitor, estado: e.target.value as any})}
                    className="w-full p-2 border border-border-subtle rounded-lg text-sm bg-page"
                  >
                    <option value="Activo">Activo</option>
                    <option value="Inactivo">Inactivo</option>
                  </select>
                </div>
              </div>
              <button 
                type="submit"
                className="w-full py-3 bg-brand text-white font-bold rounded-lg text-sm uppercase tracking-widest mt-4"
              >
                Guardar Monitor
              </button>
          </form>
        )}
      </Modal>

      <Modal isOpen={showDetailMonitor} onClose={() => setShowDetailMonitor(false)} title="Hoja de Vida del Monitor">
        {selectedMonitor && (
          <div className="space-y-6 py-2">
            <div className="flex items-center gap-4">
              <div className="w-16 h-16 bg-brand text-white rounded-2xl flex items-center justify-center text-xl font-bold">
                {selectedMonitor.nombre.split(' ').map(n => n[0]).join('')}
              </div>
              <div>
                <h5 className="text-base font-bold text-text-main">{selectedMonitor.nombre}</h5>
                <p className="text-xs text-text-muted">{selectedMonitor.email}</p>
                <div className="mt-1 flex gap-2">
                  <span className="px-2 py-0.5 bg-brand-light text-brand text-[9px] font-bold rounded uppercase">
                    {selectedMonitor.estado}
                  </span>
                </div>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="p-4 bg-page border border-border-subtle rounded-xl">
                <p className="text-[10px] font-bold text-text-muted uppercase mb-1">Programa</p>
                <p className="text-xs font-bold text-text-main">{selectedMonitor.programa}</p>
              </div>
              <div className="p-4 bg-page border border-border-subtle rounded-xl">
                <p className="text-[10px] font-bold text-text-muted uppercase mb-1">Promedio Acumulado</p>
                <p className="text-xs font-bold text-brand">{selectedMonitor.promedio}</p>
              </div>
            </div>
            <div className="p-4 bg-brand-light/10 border border-brand/5 rounded-xl">
               <h6 className="text-[10px] font-bold text-brand uppercase mb-3">Estadísticas de Monitoria</h6>
               <div className="grid grid-cols-3 gap-4 text-center">
                  <div>
                    <p className="text-[14px] font-black text-brand">{selectedMonitor.horasCumplidas}</p>
                    <p className="text-[9px] text-text-muted font-bold uppercase">Horas</p>
                  </div>
                  <div>
                    <p className="text-[14px] font-black text-brand">12</p>
                    <p className="text-[9px] text-text-muted font-bold uppercase">Sesiones</p>
                  </div>
                  <div>
                    <p className="text-[14px] font-black text-brand">98%</p>
                    <p className="text-[9px] text-text-muted font-bold uppercase">Asist.</p>
                  </div>
               </div>
            </div>
          </div>
        )}
      </Modal>

      <Modal isOpen={showDocenteReportModal} onClose={() => setShowDocenteReportModal(false)} title="Generar Informe Automático">
         <div className="space-y-6 pt-2 pb-4">
            <div className="p-4 bg-brand-light/30 border border-brand/20 rounded-xl relative overflow-hidden">
               <div className="absolute -right-4 -top-4 text-brand/10">
                 <FileText size={100} />
               </div>
               <div className="relative z-10">
                 <h4 className="text-sm font-bold text-text-main mb-1">Informe de Cumplimiento Docente</h4>
                 <p className="text-xs text-text-muted">Semestre Académico 2026-1</p>
               </div>
            </div>

            <div className="space-y-4">
              <div className="flex border-b border-border-subtle pb-3 justify-between items-center">
                 <span className="text-xs text-text-muted font-bold uppercase">Docente Titular</span>
                 <span className="text-sm font-bold text-text-main">Dr. Álvaro Guzmán</span>
              </div>
              <div className="flex border-b border-border-subtle pb-3 justify-between items-center">
                 <span className="text-xs text-text-muted font-bold uppercase">Depto.</span>
                 <span className="text-sm font-bold text-text-main">Ingeniería de Sistemas</span>
              </div>
              <div className="flex border-b border-border-subtle pb-3 justify-between items-center">
                 <span className="text-xs text-text-muted font-bold uppercase">Monitores Asignados</span>
                 <span className="text-sm font-bold text-text-main">4</span>
              </div>
              <div className="flex border-b border-border-subtle pb-3 justify-between items-center">
                 <span className="text-xs text-text-muted font-bold uppercase">Horas Validadas</span>
                 <span className="text-sm font-bold text-brand">48 / 60 (80%)</span>
              </div>
              <div className="flex border-b border-border-subtle pb-3 justify-between items-center">
                 <span className="text-xs text-text-muted font-bold uppercase">Emisión</span>
                 <span className="text-sm font-bold text-text-main">{new Date().toLocaleDateString('es-CO')}</span>
              </div>
            </div>

            <div className="bg-orange-50 border-l-4 border-orange-400 p-3 rounded-r-lg text-[11px] text-orange-800 font-medium">
               Este documento se genera con una firma criptográfica única que la Escuela de Ingeniería utilizará para certificar el cumplimiento. 
            </div>

            <button 
              onClick={() => {
                const btn = document.getElementById('btn-descarga-docente');
                if (btn) btn.innerText = 'Generando PDF...';
                setTimeout(() => {
                  setShowDocenteReportModal(false);
                  alert('¡El Informe Docente ha sido descargado en tu dispositivo como PDF!');
                }, 1500);
              }}
              id="btn-descarga-docente"
              className="w-full py-3 bg-brand text-white font-bold rounded-xl text-sm uppercase tracking-widest mt-2 flex items-center justify-center gap-2"
            >
              <Download size={18} />
              Confirmar y Descargar PDF
            </button>
         </div>
      </Modal>

      <Modal isOpen={showMonitorReportModal} onClose={() => setShowMonitorReportModal(false)} title="Generar Reporte de Horas">
         <div className="space-y-6 pt-2 pb-4">
            <div className="p-4 bg-brand-light/30 border border-brand/20 rounded-xl relative overflow-hidden">
               <div className="absolute -right-4 -top-4 text-brand/10">
                 <FileText size={100} />
               </div>
               <div className="relative z-10">
                 <h4 className="text-sm font-bold text-text-main mb-1">Reporte Mensual de Monitorías</h4>
                 <p className="text-xs text-text-muted">Mes actual: Abril 2026</p>
               </div>
            </div>

            <div className="space-y-4">
              <div className="flex border-b border-border-subtle pb-3 justify-between items-center">
                 <span className="text-xs text-text-muted font-bold uppercase">Monitor</span>
                 <span className="text-sm font-bold text-text-main">{currentMonitor.nombre}</span>
              </div>
              <div className="flex border-b border-border-subtle pb-3 justify-between items-center">
                 <span className="text-xs text-text-muted font-bold uppercase">Asignatura Principal</span>
                 <span className="text-sm font-bold text-text-main">{currentMonitor.asignaturaPrincipal}</span>
              </div>
              <div className="flex border-b border-border-subtle pb-3 justify-between items-center">
                 <span className="text-xs text-text-muted font-bold uppercase">Horas Ejecutadas</span>
                 <span className="text-sm font-bold text-brand">{currentMonitor.horasCumplidas}</span>
              </div>
              <div className="flex border-b border-border-subtle pb-3 justify-between items-center">
                 <span className="text-xs text-text-muted font-bold uppercase">Estado Validación Docente</span>
                 <span className="text-sm font-bold text-[#22c55e]">Completado (100%)</span>
              </div>
              <div className="flex border-b border-border-subtle pb-3 justify-between items-center">
                 <span className="text-xs text-text-muted font-bold uppercase">Fecha de Emisión</span>
                 <span className="text-sm font-bold text-text-main">{new Date().toLocaleDateString('es-CO')}</span>
              </div>
            </div>

            <div className="bg-brand-light/40 border-l-4 border-brand p-3 rounded-r-lg text-[11px] text-text-main font-medium">
               Documento certificado por SIGMON. Contiene el sello digital de cumplimiento para el pago o acreditación ante la Escuela.
            </div>

            <button 
              onClick={() => {
                const btn = document.getElementById('btn-descarga-monitor');
                if (btn) btn.innerText = 'Generando Reporte PDF...';
                setTimeout(() => {
                  setShowMonitorReportModal(false);
                  alert('¡El Reporte Mensual ha sido descargado en tu dispositivo!');
                }, 1500);
              }}
              id="btn-descarga-monitor"
              className="w-full py-3 bg-brand text-white font-bold rounded-xl text-sm uppercase tracking-widest mt-2 flex items-center justify-center gap-2"
            >
              <Download size={18} />
              Confirmar y Descargar PDF
            </button>
         </div>
      </Modal>

      <Modal isOpen={showDecanaturaModal} onClose={() => setShowDecanaturaModal(false)} title="Enviar Reporte a Decanatura">
         <div className="space-y-6 pt-2 pb-4">
            <div className="p-4 bg-brand-light/30 border border-brand/20 rounded-xl relative overflow-hidden">
               <div className="absolute -right-4 -top-4 text-brand/10">
                 <Send size={100} />
               </div>
               <div className="relative z-10">
                 <h4 className="text-sm font-bold text-text-main mb-1">Acta Final de Monitorías</h4>
                 <p className="text-xs text-text-muted">Consolidado Semestre 2026-1</p>
               </div>
            </div>

            <div className="space-y-4">
              <div className="flex border-b border-border-subtle pb-3 justify-between items-center">
                 <span className="text-xs text-text-muted font-bold uppercase">Destinatario</span>
                 <span className="text-sm font-bold text-text-main">Vicedecanatura Académica</span>
              </div>
              <div className="flex border-b border-border-subtle pb-3 justify-between items-center">
                 <span className="text-xs text-text-muted font-bold uppercase">Asignaturas</span>
                 <span className="text-sm font-bold text-text-main">2 (Sis. Operativos, BD)</span>
              </div>
              <div className="flex border-b border-border-subtle pb-3 justify-between items-center">
                 <span className="text-xs text-text-muted font-bold uppercase">Total Monitores</span>
                 <span className="text-sm font-bold text-text-main">4</span>
              </div>
              <div className="flex border-b border-border-subtle pb-3 justify-between items-center">
                 <span className="text-xs text-text-muted font-bold uppercase">Total Horas Validadas</span>
                 <span className="text-sm font-bold text-brand">240</span>
              </div>
            </div>

            <div className="bg-blue-50 border-l-4 border-blue-400 p-3 rounded-r-lg text-[11px] text-blue-800 font-medium">
               Al enviar este reporte, el sistema cerrará oficialmente las horas de los monitores asignados y las radicará para los trámites de certificados y pagos semestrales.
            </div>

            <button 
              onClick={() => {
                const btn = document.getElementById('btn-enviar-decanatura');
                if (btn) btn.innerText = 'Radicando Acta...';
                setTimeout(() => {
                  setShowDecanaturaModal(false);
                  alert('¡El reporte final ha sido radicado con éxito en la Decanatura!');
                }, 1500);
              }}
              id="btn-enviar-decanatura"
              className="w-full py-3 bg-brand text-white font-bold rounded-xl text-sm uppercase tracking-widest mt-2 flex items-center justify-center gap-2"
            >
              <Send size={18} />
              Firmar y Enviar Acta
            </button>
         </div>
      </Modal>

      <Modal isOpen={showCancelOfertaModal} onClose={() => setShowCancelOfertaModal(false)} title="Cancelar Oferta de Monitoria">
        {ofertaToCancel && (
          <div className="space-y-6 pt-2 pb-4">
            <div className="flex flex-col items-center justify-center text-center space-y-4">
               <div className="w-16 h-16 bg-red-100 text-red-600 rounded-full flex items-center justify-center mb-2">
                 <AlertCircle size={32} />
               </div>
               <div>
                  <h4 className="text-lg font-bold text-text-main mb-2">¿Está seguro de cancelar esta oferta?</h4>
                  <p className="text-xs text-text-muted max-w-[280px] mx-auto leading-relaxed">
                    Esta acción cambiará el estado de la oferta a Cancelado. Los estudiantes con reservas activas serán notificados automáticamente.
                  </p>
               </div>
            </div>

            <div className="bg-border-subtle/30 border border-border-subtle p-4 rounded-xl">
               <p className="text-[10px] font-bold text-text-muted uppercase tracking-widest mb-1">Oferta a Cancelar</p>
               <p className="font-bold text-text-main">
                 {DUMMY_ASIGNATURAS.find(a => a.id === ofertaToCancel.asignaturaId)?.nombre} — {monitores.find(m => m.id === ofertaToCancel.monitorId)?.nombre}
               </p>
               <p className="text-[11px] text-text-muted mt-1">{ofertaToCancel.horario} | {ofertaToCancel.aula} | {ofertaToCancel.cuposReservados} reservas activas</p>
            </div>

            <div className="flex flex-col gap-2">
              <button 
                onClick={handleCancelOferta}
                className="w-full py-3 bg-red-600 text-white font-bold rounded-xl text-sm uppercase tracking-widest mt-2 hover:bg-red-700 transition-colors"
              >
                Sí, Cancelar Oferta
              </button>
              <button 
                onClick={() => setShowCancelOfertaModal(false)}
                className="w-full py-3 bg-transparent border border-border-subtle text-text-main font-bold rounded-xl text-sm justify-center flex items-center hover:bg-border-subtle/50 transition-colors"
              >
                No, volver atrás
              </button>
            </div>
          </div>
        )}
      </Modal>

      <style>{`
        .custom-scrollbar::-webkit-scrollbar {
          width: 5px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
          background: transparent;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
          background: #e2e8f0;
          border-radius: 10px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover {
          background: #cbd5e1;
        }
      `}</style>
    </div>
  );
}

