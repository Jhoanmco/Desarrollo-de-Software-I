import React from 'react';

export type Role = 'Admin' | 'Monitor' | 'Estudiante' | 'Catedratico';

export interface Monitor {
  id: string;
  nombre: string;
  programa: string;
  promedio: number;
  asignaturaPrincipal: string;
  estado: 'Activo' | 'Deshabilitado';
  horasCumplidas: number;
  email: string;
}

export interface Asignatura {
  id: string;
  nombre: string;
  codigo: string;
  departamento: string;
}

export interface Oferta {
  id: string;
  asignaturaId: string;
  monitorId: string;
  horario: string; // ISO string or format like "Lunes 14:00 - 16:00"
  aula: string;
  cuposMax: number;
  cuposReservados: number;
  estado: 'Activo' | 'Cancelado' | 'Pendiente';
}

export interface Reserva {
  id: string;
  ofertaId: string;
  estudianteNombre: string;
  estudianteEmail: string;
  fecha: string;
  asistencia: boolean | null; // null = pendiente, true = asistio, false = inasistencia
}

export interface TabItem {
  id: string;
  title: string;
  desc: string;
  icon: React.ReactNode;
  num: number;
  actions?: string[];
}
