import { Monitor, Asignatura, Oferta } from './types';

export const DUMMY_MONITORES: Monitor[] = [
  {
    id: 'm1',
    nombre: 'Juan Pérez',
    programa: 'Ingeniería de Sistemas',
    promedio: 4.5,
    asignaturaPrincipal: 'Estructuras de Datos',
    estado: 'Activo',
    horasCumplidas: 15,
    email: 'juan.perez@universidad.edu.co'
  },
  {
    id: 'm2',
    nombre: 'María García',
    programa: 'Ingeniería Electrónica',
    promedio: 4.8,
    asignaturaPrincipal: 'Cálculo Multivariable',
    estado: 'Activo',
    horasCumplidas: 8,
    email: 'maria.garcia@universidad.edu.co'
  },
  {
    id: 'm3',
    nombre: 'Carlos López',
    programa: 'Matemáticas',
    promedio: 4.2,
    asignaturaPrincipal: 'Álgebra Lineal',
    estado: 'Deshabilitado',
    horasCumplidas: 0,
    email: 'carlos.lopez@universidad.edu.co'
  }
];

export const DUMMY_ASIGNATURAS: Asignatura[] = [
  { id: 'a1', nombre: 'Estructuras de Datos', codigo: '750001M', departamento: 'Sistemas' },
  { id: 'a2', nombre: 'Cálculo Multivariable', codigo: '111002M', departamento: 'Matemáticas' },
  { id: 'a3', nombre: 'Álgebra Lineal', codigo: '111003M', departamento: 'Matemáticas' },
  { id: 'a4', nombre: 'Introducción a la Programación', codigo: '750002M', departamento: 'Sistemas' }
];

export const DUMMY_OFERTA: Oferta[] = [
  {
    id: 'o1',
    asignaturaId: 'a1',
    monitorId: 'm1',
    horario: 'Lunes 14:00 - 16:00',
    aula: '401',
    cuposMax: 20,
    cuposReservados: 12,
    estado: 'Activo'
  },
  {
    id: 'o2',
    asignaturaId: 'a2',
    monitorId: 'm2',
    horario: 'Martes 10:00 - 12:00',
    aula: '202',
    cuposMax: 15,
    cuposReservados: 8,
    estado: 'Activo'
  }
];
