import React, { useState } from 'react';
import { AnimatePresence } from 'motion/react';
import { LandingPage } from './components/LandingPage';
import { LoginPage } from './components/LoginPage';
import { DashboardPlaceholder } from './components/DashboardPlaceholder';

/**
 * SIGMON - Entry Point
 * This file handles the main routing logic between the Landing Page, 
 * the Login simulation, and the Main System Dashboard.
 */

export default function App() {
  // Current view management
  const [currentView, setCurrentView] = useState<'landing' | 'login' | 'dashboard'>('landing');
  
  // Simulated user role
  const [userRole, setUserRole] = useState<'admin' | 'monitor' | 'estudiante' | 'catedratico'>('admin');

  // Handle successful login
  const handleLoginSuccess = (role: string) => {
    setUserRole(role as any);
    setCurrentView('dashboard');
  };

  // Handle logout
  const handleLogout = () => {
    setCurrentView('landing');
  };

  return (
    <>
      <AnimatePresence mode="wait">
        {currentView === 'landing' && (
          <LandingPage key="landing" onLogin={() => setCurrentView('login')} />
        )}
        
        {currentView === 'login' && (
          <LoginPage 
            key="login"
            onLogin={handleLoginSuccess} 
            onBack={() => setCurrentView('landing')} 
          />
        )}

        {currentView === 'dashboard' && (
          <DashboardPlaceholder 
            key="dashboard"
            userRole={userRole} 
            onLogout={handleLogout} 
          />
        )}
      </AnimatePresence>

      <style>{`
        .custom-scrollbar::-webkit-scrollbar {
          width: 5px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
          background: transparent;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
          background: #e2e8f0;
          border-radius: 10px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover {
          background: #cbd5e1;
        }
        
        /* Global font smoothing */
        body {
          -webkit-font-smoothing: antialiased;
          -moz-osx-font-smoothing: grayscale;
        }
      `}</style>
    </>
  );
}
