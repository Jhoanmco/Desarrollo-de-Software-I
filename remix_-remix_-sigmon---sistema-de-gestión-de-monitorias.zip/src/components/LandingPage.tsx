import React, { useState, useRef, useEffect } from 'react';
import { motion } from 'motion/react';
import { 
  ArrowUpRight, 
  ChevronRight, 
  Menu, 
  Plus, 
  MapPin, 
  GraduationCap,
  Sun,
  Moon
} from 'lucide-react';
import { cn } from '../lib/utils';

interface LandingPageProps {
  onLogin: () => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({ onLogin }) => {
  const [theme, setTheme] = useState<'dark' | 'light'>('dark');
  const videoRef = useRef<HTMLVideoElement>(null);

  const isDark = theme === 'dark';

  useEffect(() => {
    // Attempt playback multiple times in case of initial browser block
    const playVideo = () => {
      if (videoRef.current) {
        videoRef.current.play().catch(error => {
          console.warn("Autoplay was prevented:", error);
        });
      }
    };
    
    playVideo();
    window.addEventListener('click', playVideo, { once: true });
    return () => window.removeEventListener('click', playVideo);
  }, []);

  return (
    <div className={cn(
      "min-h-screen overflow-hidden font-sans relative selection:bg-brand/30 transition-colors duration-700",
      isDark ? "text-white" : "text-black"
    )}>
      {/* Layer -10: Base Color */}
      <div className={cn(
        "absolute inset-0 z-[-10] transition-colors duration-700",
        isDark ? "bg-black" : "bg-white"
      )} />

      {/* Layer -5: Video Background (Highest priority for visibility) */}
      <div className="absolute inset-0 z-[-5] overflow-hidden pointer-events-none">
        <video 
          ref={videoRef}
          autoPlay 
          loop 
          muted 
          playsInline 
          preload="auto"
          className={cn(
            "w-full h-full object-cover transition-opacity duration-1000 scale-[1.05]",
            isDark ? "opacity-90" : "opacity-60"
          )}
        >
          {/* Priority 1: High quality silver fluid */}
          <source src="https://player.vimeo.com/external/517618991.sd.mp4?s=3401569720ef60473a216c5617d59048a9062b1a&profile_id=164&oauth2_token_id=57447761" type="video/mp4" />
          {/* Priority 2: Alternative silver motion */}
          <source src="https://cdn.pixabay.com/video/2021/09/01/87103-595446059_large.mp4" type="video/mp4" />
        </video>
        
        {/* Subtle Vignette */}
        <div className={cn(
          "absolute inset-0 transition-opacity duration-700 pointer-events-none",
          isDark 
            ? "bg-gradient-to-br from-black/60 via-transparent to-black/60" 
            : "bg-gradient-to-br from-white/40 via-transparent to-white/40"
        )} />
      </div>

      {/* Layer -1: Decorative Glows */}
      <div className="absolute inset-0 z-[-1] overflow-hidden pointer-events-none">
        <motion.div 
          animate={{ x: [0, 50, 0], y: [0, 30, 0], scale: [1, 1.1, 1] }}
          transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
          className={cn(
            "absolute top-[-10%] left-[-10%] w-[60%] h-[60%] blur-[130px] rounded-full transition-colors duration-700 opacity-30",
            isDark ? "bg-brand/20" : "bg-brand/10"
          )} 
        />
      </div>
      
      <motion.div 
        animate={{ 
          x: [0, -40, 0], 
          y: [0, 50, 0],
          scale: [1, 1.2, 1]
        }}
        transition={{ 
          duration: 15, 
          repeat: Infinity, 
          ease: "linear" 
        }}
        className={cn(
          "absolute bottom-[-10%] right-[-10%] w-[50%] h-[50%] blur-[100px] rounded-full pointer-events-none transition-colors duration-700",
          isDark ? "bg-white/5" : "bg-brand/10"
        )} 
      />

      {/* Floating Particles/Dots */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        {[...Array(6)].map((_, i) => (
          <motion.div
            key={i}
            initial={{ 
              x: Math.random() * 100 + "%", 
              y: Math.random() * 100 + "%",
              opacity: 0
            }}
            animate={{ 
              y: ["-10%", "110%"],
              opacity: [0, 0.4, 0]
            }}
            transition={{ 
              duration: 10 + Math.random() * 20, 
              repeat: Infinity, 
              delay: Math.random() * 10,
              ease: "linear" 
            }}
            className={cn(
              "absolute w-1 h-1 rounded-full",
              isDark ? "bg-white/20" : "bg-brand/20"
            )}
          />
        ))}
      </div>
      
      {/* Navigation */}
      <nav className="relative z-50 flex items-center justify-between px-6 py-6 md:px-12">
        <motion.div 
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          className="flex items-center gap-2"
        >
          <div className="w-8 h-8 bg-brand rounded-lg flex items-center justify-center">
            <GraduationCap className="text-white w-5 h-5" />
          </div>
          <span className={cn(
            "text-xl font-bold tracking-tight transition-colors duration-700",
            isDark ? "text-white" : "text-black"
          )}>SIGMON<span className="text-[10px] align-top ml-0.5 opacity-50">TM</span></span>
        </motion.div>

        <motion.div 
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className={cn(
            "hidden md:flex items-center gap-8 text-[11px] font-bold uppercase tracking-widest transition-colors duration-700",
            isDark ? "text-white/50" : "text-black/50"
          )}
        >
          <a href="#" className={cn(
            "flex items-center gap-1 transition-colors",
            isDark ? "text-white hover:text-brand" : "text-black hover:text-brand"
          )}>
            <span className="w-1 h-1 bg-brand rounded-full"></span> Inicio
          </a>
          <a href="#" className={isDark ? "hover:text-white" : "hover:text-black"}>Nosotros</a>
          <a href="#" className={isDark ? "hover:text-white" : "hover:text-black"}>Oferta <span>(07)</span></a>
          <a href="#" className={isDark ? "hover:text-white" : "hover:text-black"}>Contacto</a>
        </motion.div>

        <motion.div 
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          className="flex items-center gap-4"
        >
          <button 
            onClick={() => setTheme(isDark ? 'light' : 'dark')}
            className={cn(
              "p-2.5 rounded-full border transition-all duration-300 active:scale-90",
              isDark 
                ? "bg-white/5 border-white/10 text-white hover:bg-white/10" 
                : "bg-black/5 border-black/10 text-black hover:bg-black/10"
            )}
            title={isDark ? "Cambiar a tema claro" : "Cambiar a tema oscuro"}
          >
            {isDark ? <Sun size={16} /> : <Moon size={16} />}
          </button>

          <div className="md:hidden">
            <button className={cn(
              "p-2 rounded-lg transition-colors",
              isDark ? "hover:bg-white/10 text-white" : "hover:bg-black/10 text-black"
            )}>
              <Menu size={20} />
            </button>
          </div>
          <button 
            onClick={onLogin}
            className={cn(
              "hidden md:flex items-center gap-2 px-5 py-2.5 text-[11px] font-bold uppercase tracking-widest rounded-full transition-all transform active:scale-95",
              isDark 
                ? "bg-white text-black hover:bg-brand hover:text-white" 
                : "bg-black text-white hover:bg-brand"
            )}
          >
            SISTEMA ACADÉMICO
          </button>
        </motion.div>
      </nav>

      {/* Hero Section */}
      <main className="relative z-10 px-6 md:px-12 pt-20 md:pt-32 flex flex-col md:flex-row justify-between items-end min-h-[70vh]">
        <div className="flex-1">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="flex flex-col"
          >
            <h1 className={cn(
              "text-[15vw] md:text-[10vw] leading-[0.85] font-light tracking-tighter transition-colors duration-700",
              isDark ? "text-white/90" : "text-black/90"
            )}>
              Gestión
            </h1>
            <div className="flex items-center gap-4 md:gap-8 mt-[-1vw]">
               <span className={cn(
                 "text-[12vw] md:text-[8vw] font-serif italic lowercase transition-colors duration-700",
                 isDark ? "text-white/30" : "text-black/20"
               )}>&</span>
               <h1 className={cn(
                 "text-[15vw] md:text-[10vw] leading-[0.85] font-light tracking-tighter transition-colors duration-700",
                 isDark ? "text-white" : "text-black"
               )}>
                Monitoría
               </h1>
            </div>
          </motion.div>

          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.5 }}
            className="mt-20 max-w-sm"
          >
            <div className={cn(
              "flex items-start gap-4 border-l pl-6 py-2 transition-colors duration-700",
              isDark ? "text-white/40 border-white/20" : "text-black/50 border-black/10"
            )}>
              <Plus size={16} className="mt-1 shrink-0" />
              <p className="text-[13px] leading-relaxed font-medium">
                Sincronizamos el éxito estudiantil mediante un sistema inteligente de acompañamiento académico. 
                Optimiza tus horas y potencia tu aprendizaje.
              </p>
            </div>
            <p className={cn(
              "mt-8 text-[11px] font-bold uppercase tracking-[0.2em] transition-colors duration-700",
              isDark ? "text-white/20" : "text-black/20"
            )}>
              © 2026 SIGMON ACADÉMICO / UNIVALLE
            </p>
          </motion.div>
        </div>

        {/* Feature List on the right (like image) */}
        <div className="mt-20 md:mt-0 flex flex-col items-end gap-6 text-right pb-10">
          {[
            { id: '01', title: 'Reserva de cupos' },
            { id: '02', title: 'Control de asistencia' },
            { id: '03', title: 'Validación de horas' },
            { id: '04', title: 'Reportes PDF' },
          ].map((item, idx) => (
            <motion.div 
              key={item.id}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.4 + (idx * 0.1) }}
              className="group cursor-pointer"
            >
              <div className="flex items-center gap-4">
                <span className={cn(
                  "text-[12px] font-serif italic transition-colors italic",
                  isDark ? "text-white/30 group-hover:text-brand" : "text-black/30 group-hover:text-brand"
                )}>({item.id})</span>
                <span className={cn(
                  "text-lg md:text-xl font-medium tracking-tight group-hover:mr-2 transition-all",
                  isDark ? "text-white" : "text-black"
                )}>{item.title}</span>
              </div>
            </motion.div>
          ))}

          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.8 }}
            className="mt-10 flex flex-col gap-3 items-end"
          >
            <button 
              onClick={onLogin}
              className={cn(
                "flex items-center gap-3 backdrop-blur-xl border px-8 py-4 rounded-full transition-all group active:scale-95",
                isDark 
                  ? "bg-white/10 hover:bg-white/20 border-white/10 text-white" 
                  : "bg-black/5 hover:bg-black/10 border-black/10 text-black"
              )}
            >
              <span className="text-sm font-bold uppercase tracking-widest">Empezar Sesión</span>
              <div className={cn(
                "w-8 h-8 rounded-full flex items-center justify-center group-hover:rotate-45 transition-transform",
                isDark ? "bg-white text-black" : "bg-black text-white"
              )}>
                <ArrowUpRight size={18} />
              </div>
            </button>
            <div className={cn(
              "flex items-center gap-2 text-[10px] font-bold uppercase tracking-[0.3em] transition-colors duration-700",
              isDark ? "text-white/30" : "text-black/30"
            )}>
               BASADO EN CALI, CO <MapPin size={10} />
            </div>
          </motion.div>
        </div>
      </main>

      {/* Decorative large sphere */}
      <motion.div 
        animate={{ 
          y: [0, -20, 0],
          rotate: [0, 10, 0]
        }}
        transition={{ 
          duration: 10, 
          repeat: Infinity, 
          ease: "easeInOut" 
        }}
        className={cn(
          "absolute right-[20%] top-[40%] w-32 h-32 md:w-64 md:h-64 rounded-full blur-[1px] border pointer-events-none transition-all duration-700 -z-0",
          isDark 
            ? "bg-gradient-to-br from-white/10 to-transparent border-white/5 opacity-20" 
            : "bg-gradient-to-br from-brand/10 to-transparent border-brand/5 opacity-40"
        )} 
      />
    </div>
  );
};
