import React, { useState, useMemo } from 'react';
import { 
  Plus, Edit2, XCircle, Search, GraduationCap, Calendar, Clock,
  CheckCircle2, AlertCircle, FileText, Activity, Download, Send, Menu,
  ChevronDown, Info, X, UserCheck, Users, BookOpen, Home, CalendarCheck, ClipboardCheck,
  BarChart3, Contact, Settings
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from '../lib/utils';
import { Monitor, Oferta, Reserva, TabItem } from '../types';
import { DUMMY_MONITORES, DUMMY_ASIGNATURAS, DUMMY_OFERTA } from '../constants';

interface DashboardPlaceholderProps {
  userRole: string;
  onLogout: () => void;
}

// Simple StatCard reused from previous App.tsx
const StatCard = ({ label, value, icon: Icon, color }: any) => (
  <motion.div 
    initial={{ opacity: 0, y: 10 }}
    animate={{ opacity: 1, y: 0 }}
    className="glass-card p-5 rounded-2xl flex flex-col justify-between"
  >
    <div className="flex items-center justify-between mb-3">
      <p className="text-[11px] font-bold text-text-muted uppercase tracking-wider">{label}</p>
      <Icon className={cn("w-4 h-4", color.replace('bg-', 'text-').replace('-100', '-600'))} />
    </div>
    <p className="text-2xl font-extrabold text-text-main">{value}</p>
  </motion.div>
);

export const DashboardPlaceholder: React.FC<DashboardPlaceholderProps> = ({ userRole, onLogout }) => {
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [activeTab, setActiveTab] = useState('inicio');

  return (
    <div className="min-h-screen bg-transparent font-sans text-text-main flex flex-col md:flex-row h-screen overflow-hidden">
      <aside className={cn(
        "glass-nav overflow-hidden flex flex-col z-20 transition-all duration-300 shrink-0",
        isSidebarOpen ? "w-[280px]" : "w-[80px]"
      )}>
        <div className="p-6 bg-white/20 border-b border-white/30 flex flex-col items-start">
          <h1 className="font-extrabold text-lg flex items-center gap-2 text-brand">
            <GraduationCap size={20} />
            {isSidebarOpen && <span>SIGMON</span>}
          </h1>
        </div>
        <div className="flex-1 py-4 px-3 overflow-y-auto">
          <p className="text-[10px] uppercase font-bold text-text-muted mb-4 px-3">Menú Principal</p>
          <div className="space-y-1">
             {['inicio', 'oferta', 'reserva', 'reportes'].map(id => (
               <button 
                key={id} 
                onClick={() => setActiveTab(id)}
                className={cn(
                  "w-full px-3 py-2.5 rounded-xl text-sm font-bold capitalize flex items-center gap-3 transition-all",
                  activeTab === id ? "bg-brand text-white shadow-lg shadow-brand/20" : "text-text-muted hover:bg-white/50"
                )}
               >
                 <div className="w-5 h-5 flex items-center justify-center">
                   {id === 'inicio' ? <Home size={18} /> : id === 'oferta' ? <BookOpen size={18} /> : id === 'reserva' ? <CalendarCheck size={18} /> : <BarChart3 size={18} />}
                 </div>
                 {isSidebarOpen && id}
               </button>
             ))}
          </div>
        </div>
      </aside>

      <main className="flex-1 flex flex-col overflow-hidden">
        <header className="h-16 glass-header px-8 flex items-center justify-between sticky top-0 transition-all">
          <div className="flex items-center gap-4">
            <button onClick={() => setIsSidebarOpen(!isSidebarOpen)} className="p-2 hover:bg-white/50 rounded-lg text-text-muted">
              <Menu size={20} />
            </button>
            <h2 className="font-bold text-text-main">
              Dashboard / <span className="capitalize text-brand">{userRole}</span>
            </h2>
          </div>
          <div className="flex items-center gap-4">
             <div className="text-right hidden sm:block">
               <p className="text-xs font-bold text-text-main leading-none">Usuario Demo</p>
               <p className="text-[10px] text-text-muted uppercase font-bold mt-1 tracking-wider">{userRole}</p>
             </div>
             <button 
              onClick={onLogout}
              className="px-4 py-2 bg-red-50 text-red-600 text-[10px] font-bold rounded-xl border border-red-100 hover:bg-red-100 transition-colors"
             >
               CERRAR SESIÓN
             </button>
          </div>
        </header>

        <div className="flex-1 overflow-y-auto p-8 max-w-7xl mx-auto w-full space-y-8">
           <div className="flex flex-col gap-1">
             <h3 className="text-2xl font-black text-text-main tracking-tight italic">Bienvenido de nuevo.</h3>
             <p className="text-text-muted text-sm font-medium">Aquí tienes el resumen de tus monitorías para hoy.</p>
           </div>

           <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <StatCard label="Horas este mes" value="24h" icon={Clock} color="bg-blue-100" />
              <StatCard label="Asistentes" value="128" icon={Users} color="bg-green-100" />
              <StatCard label="Calificación" value="4.8" icon={Activity} color="bg-orange-100" />
              <StatCard label="Sesiones" value="12" icon={Calendar} color="bg-purple-100" />
           </div>

           <div className="glass-card rounded-3xl p-8 border border-white/80">
              <div className="flex items-center justify-between mb-8">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-brand-light rounded-2xl flex items-center justify-center text-brand">
                    <Info size={20} />
                  </div>
                  <div>
                    <h4 className="font-bold text-text-main leading-none">Integración del Sistema</h4>
                    <p className="text-xs text-text-muted mt-1">Este es un área reservada para tu sistema central.</p>
                  </div>
                </div>
              </div>
              <div className="py-20 flex flex-col items-center justify-center text-center max-w-sm mx-auto border-2 border-dashed border-border-subtle rounded-[40px]">
                 <div className="bg-white/60 p-4 rounded-3xl shadow-sm mb-4">
                  <Plus className="text-text-muted" size={32} />
                 </div>
                 <h5 className="font-bold text-text-main mb-2">Conectar componente principal</h5>
                 <p className="text-[12px] text-text-muted leading-relaxed px-4">
                   Reemplaza este marcador de posición con tu componente de lógica central para completar la migración exitosa de SIGMON.
                 </p>
              </div>
           </div>
        </div>
      </main>
    </div>
  );
};
