import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  ArrowLeft, 
  Lock, 
  Mail, 
  ArrowRight,
  GraduationCap,
  AlertCircle
} from 'lucide-react';

interface LoginPageProps {
  onLogin: (role: string) => void;
  onBack: () => void;
}

export const LoginPage: React.FC<LoginPageProps> = ({ onLogin, onBack }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) {
      setError('Por favor completa todos los campos.');
      return;
    }

    setIsLoading(true);
    // Simulation
    setTimeout(() => {
      // Determine role based on email for demo purposes
      let role = 'estudiante';
      if (email.includes('admin')) role = 'admin';
      if (email.includes('monitor')) role = 'monitor';
      if (email.includes('docente') || email.includes('profesor')) role = 'catedratico';
      
      onLogin(role);
      setIsLoading(false);
    }, 1500);
  };

  return (
    <div className="min-h-screen landing-dark flex items-center justify-center p-6 relative overflow-hidden">
      {/* Decorative Blur */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-brand/5 blur-[120px] rounded-full pointer-events-none" />

      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="w-full max-w-md relative z-10"
      >
        <button 
          onClick={onBack}
          className="mb-8 flex items-center gap-2 text-white/50 hover:text-white transition-colors group"
        >
          <ArrowLeft size={16} className="group-hover:-translate-x-1 transition-transform" />
          <span className="text-xs font-bold uppercase tracking-widest">Volver</span>
        </button>

        <div className="bg-white/5 backdrop-blur-3xl border border-white/10 rounded-[40px] p-8 md:p-12 shadow-2xl">
          <div className="flex flex-col items-center mb-10">
            <div className="w-16 h-16 bg-brand rounded-2xl flex items-center justify-center mb-6 shadow-lg shadow-brand/20">
              <GraduationCap className="text-white w-8 h-8" />
            </div>
            <h2 className="text-3xl font-light tracking-tight text-white mb-2">Bienvenido</h2>
            <p className="text-white/40 text-sm font-medium">Ingresa tus credenciales institucionales</p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            <AnimatePresence mode="wait">
              {error && (
                <motion.div 
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  exit={{ opacity: 0, height: 0 }}
                  className="bg-red-500/10 border border-red-500/20 rounded-2xl p-4 flex items-start gap-3"
                >
                  <AlertCircle size={18} className="text-red-500 shrink-0" />
                  <p className="text-red-200 text-xs font-medium">{error}</p>
                </motion.div>
              )}
            </AnimatePresence>

            <div className="space-y-4">
              <div className="relative group">
                <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-white/30 group-focus-within:text-brand transition-colors" size={18} />
                <input 
                  type="email" 
                  placeholder="Correo institucional"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full bg-white/5 border border-white/10 rounded-2xl py-4 pl-12 pr-4 text-sm focus:outline-none focus:ring-2 focus:ring-brand/30 focus:border-brand/50 transition-all placeholder:text-white/20"
                />
              </div>

              <div className="relative group">
                <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-white/30 group-focus-within:text-brand transition-colors" size={18} />
                <input 
                  type="password" 
                  placeholder="Contraseña"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full bg-white/5 border border-white/10 rounded-2xl py-4 pl-12 pr-4 text-sm focus:outline-none focus:ring-2 focus:ring-brand/30 focus:border-brand/50 transition-all placeholder:text-white/20"
                />
              </div>
            </div>

            <div className="flex items-center justify-between px-1">
              <label className="flex items-center gap-2 cursor-pointer group">
                <input type="checkbox" className="w-4 h-4 rounded border-white/10 bg-white/5 text-brand focus:ring-brand/30 focus:ring-offset-0" />
                <span className="text-[11px] font-bold text-white/30 uppercase tracking-widest group-hover:text-white/50 transition-colors">Recordarme</span>
              </label>
              <a href="#" className="text-[11px] font-bold text-brand uppercase tracking-widest hover:text-white transition-colors">¿Olvidaste tu clave?</a>
            </div>

            <button 
              disabled={isLoading}
              className="w-full py-4 bg-white text-black font-bold rounded-2xl text-[11px] uppercase tracking-[0.2em] hover:bg-brand hover:text-white transition-all transform active:scale-[0.98] flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed group shadow-xl"
            >
              {isLoading ? (
                <div className="w-5 h-5 border-2 border-current border-t-transparent rounded-full animate-spin" />
              ) : (
                <>
                  Entrar al sistema
                  <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
                </>
              )}
            </button>
          </form>

          <p className="mt-10 text-center text-[10px] font-bold text-white/20 uppercase tracking-[0.3em]">
            DIRECCIÓN ACADÉMICA V1.0
          </p>
        </div>
      </motion.div>
    </div>
  );
};
